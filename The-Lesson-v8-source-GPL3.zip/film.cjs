// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Local original SVG animation. Character contours and pose curves are authored,
// not generated video. English mouth activity follows the actual dialogue audio.
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const sharp=require('sharp');
const C=require('./draw-core.cjs');
const G=require('./acting-geometry.cjs');
const Faces=require('./facial-acting.cjs');
const Table=require('./props-table.cjs');
const Acting=require('./scene-acting.cjs');
const {p,f,ease,mix,clamp,rng,ribbon,hand,skin,skinShade,skinLight,ink}=C;
const ROOT=__dirname, ASSETS=path.join(ROOT,'assets'),QA=path.join(ROOT,'qa');
const FFMPEG=process.env.FFMPEG||'ffmpeg';
const envelopes=JSON.parse(fs.readFileSync(path.join(ROOT,'timing/mouth-envelopes-120fps.json'),'utf8'));
const dialogue=JSON.parse(fs.readFileSync(path.join(ROOT,'DIALOGUE.json'),'utf8'));
const visemes=fs.existsSync(path.join(ROOT,'timing/viseme-cues.json'))?JSON.parse(fs.readFileSync(path.join(ROOT,'timing/viseme-cues.json'),'utf8')):null;
const propDefs=fs.readFileSync(path.join(ASSETS,'props.svg'),'utf8').match(/<defs>([\s\S]*?)<\/defs>/)[1];
const at=(t,a,b)=>ease((t-a)/(b-a));
const point=(a,b,q)=>a.map((v,i)=>mix(v,b[i],q));
const smoothPoint=(a,b,t,x,y)=>point(a,b,at(t,x,y));
function mouth(who,t){let v=0;for(const cue of Object.values(envelopes.cues)){if(cue.character!==who)continue;let ix=(t-cue.start)*envelopes.fps;if(ix<0||ix>cue.values.length-1)continue;let i=Math.floor(ix);v=Math.max(v,mix(cue.values[i],cue.values[Math.min(i+1,cue.values.length-1)],ix-i));}return clamp(v*1.08)}
function prop(id,x,y,s=1,angle=0){return `<use href="#${id}" transform="translate(${f(x)},${f(y)}) rotate(${f(angle)}) scale(${s})"/>`}
function chair(x,y,s=1){return prop('prop-chair-upright',x,y,s)}
function xf(P){return `translate(${f(P.x)},${f(P.y)}) rotate(${f(P.angle||0)}) scale(${P.s||1})`}
function world(P,v){let a=(P.angle||0)*Math.PI/180,s=P.s||1;return[P.x+s*(v[0]*Math.cos(a)-v[1]*Math.sin(a)),P.y+s*(v[0]*Math.sin(a)+v[1]*Math.cos(a))]}
function local(P,v){let a=-(P.angle||0)*Math.PI/180,s=P.s||1,x=(v[0]-P.x)/s,y=(v[1]-P.y)/s;return[x*Math.cos(a)-y*Math.sin(a),x*Math.sin(a)+y*Math.cos(a)]}
const COLORS={fin:['#687f94','#465d73','#92a2ae','#394b5b'],zei:['#82938a','#596e6c','#a2b0a1','#b9c4c2'],teacher:['#82919e','#566c7e','#abb9c1','#e3e7e3']};
function coatFlat(kind,P){
 const [co,sh,li,shirt]=COLORS[kind];let drop=P.drop||0,lean=P.torso||0;
 const d=`M-53,121 Q-76,150 -136,${f(166+drop)} Q-172,${f(178+drop)} -181,228 L${f(-167+lean)},412 L-136,487 Q-45,506 101,486 L159,450 L177,239 Q164,183 111,165 L48,130 Q2,161 -53,121Z`;
 let s=p(d,co,ink,4.4);
 s+=p('M-28,159Q-12,190 29,181L64,174L87,482Q19,490 -33,483L-51,192Z',shirt,ink,2.6);
 s+=p('M-151,193Q-115,210 -107,284L-134,462L-163,410L-173,238Z',sh,'none',0,'opacity=".72"');
 s+=p('M106,182Q134,225 140,292L116,469L149,448L173,239Q155,195 106,182Z',sh,'none',0,'opacity=".72"');
 s+=p('M-52,139L-78,168L-33,218L-8,177L-31,153Z',li,ink,2.5)+p('M47,140L82,169L49,218L23,179L43,160Z',li,ink,2.5);
 s+=p('M-40,215L-28,475M51,219L66,478','none',ink,2);
 if(kind!=='teacher')s+=p('M-102,229L-56,233L-51,300Q-76,315 -105,300Z',co,ink,2.3)+p('M-103,234L-56,238M-96,292l30,3','none',li,1.4);
 s+=p(`M81,242Q107,258 104,297M-134,265Q-113,286 -117,318M-122,366l-12,37M89,372q21,33 14,70M-20,457q19,-9 40,-1M-131,468q47,14 77,10`,'none',sh,3.3);
 s+=p('M-128,257q9,26 6,43M98,323l-8,22M-100,420q17,-11 24,-8M77,444l10,16','none',li,1.7);
 for(let y=259;y<472;y+=65)s+=`<circle cx="58" cy="${y}" r="3.9" fill="#bfcbca" stroke="${ink}" stroke-width="1.3"/>`;
 s+=C.textile(`${kind}coat`,d,li);
 s+=p('M-42,108L-48,149Q-22,188 23,176L49,145L36,108Z',skin,ink,3)+p('M-42,111L35,111L34,137Q8,157 -35,151Z',skinShade,'none',0,'opacity=".55"');
 return s;
}
function coat(kind,P){return G.warpMarkup(coatFlat(kind,P),v=>G.bodyPoint(P,v))}
function viseme(who,t){const events=visemes&&(visemes.events||visemes.cues||[]);if(!events)return'neutral';const e=events.find(e=>e.character===who&&t>=e.start&&t<e.end);return e?(e.shape||e.viseme||'neutral'):'neutral'}
function teacherHead(t,options){
 let s=C.face('zei',t%4,options);
 s+=p('M-101,-43Q-120,-80 -102,-112Q-94,-145 -63,-141Q-35,-164 -7,-149Q22,-162 48,-147Q83,-148 103,-119L108,-77L92,-27L78,-46L76,-92Q20,-109 -44,-94L-78,-50L-89,-25Z','#6a645e',ink,4);
 s+=p('M-93,-101Q-59,-127 -25,-124M-15,-131q34,-6 65,5M54,-121l28,15','none','#a9a398',2.1);
 s+=p('M-90,23Q-75,55 -56,61L-37,58Q-16,48 1,57Q21,46 42,58L63,51L92,22L89,84Q70,126 28,140Q-13,151 -51,125Q-84,104 -90,65ZM-39,68Q-4,53 40,67L48,102Q4,120 -41,102Z','#736b65',ink,2.2,'fill-rule="evenodd"');
 const r=rng(415);for(let i=0;i<24;i++){let x=-67+r()*135,y=100+r()*31;if(x>-43&&x<44&&y<117)continue;s+=p(`M${f(x)},${f(y)}l${f(r()*3-2)},${f(4+r()*6)}`,'none','#b7b0a3',1.2)}
 s+=p('M-67,-42q19,-7 35,-3M31,-42q22,-3 37,3M-64,15q9,3 17,0M43,14l14,-2','none','#aa9ea8',1.5);
 return s;
}
function grip(x,y,angle=0){return `<g transform="translate(${f(x)},${f(y)}) rotate(${f(angle)})">`+p('M-18,-19Q-5,-28 13,-22L30,-12Q37,-5 32,2L17,-1Q9,-10 3,-7Q0,5 11,9L27,11Q32,19 21,22L-1,17Q-16,15 -22,1Z',skin,ink,2.7)+p('M5,-18l16,6M1,-12l14,6M0,8l13,5','none','#a18f9e',1.6)+'</g>'}
function loose(x,y,mirror=false){return `<g transform="translate(${f(x)},${f(y)}) scale(${mirror?-1:1},1)">`+p('M-17,-13Q-2,-20 13,-10L31,0L43,18Q44,25 37,24L24,11L17,6L32,30Q34,38 27,38L10,17L6,14L16,37Q18,46 10,44L-5,20L-16,14Z',skin,ink,2.7)+p('M-9,-5l18,11M7,15l9,13','none','#a18f9e',1.5)+'</g>'}
function palmUp(x,y){return `<g transform="translate(${f(x)},${f(y)})">`+p('M-21,-6Q-9,-13 0,-4Q18,8 35,0L50,-15Q58,-21 62,-14Q62,-7 49,10Q30,27 4,25L-19,12Z',skin,ink,2.6)+p('M-10,6q20,10 37,1M34,6l12,-12','none','#a18f9e',1.7)+'</g>'}
function arm(kind,side,A,layer){
 if(!A||A.hidden)return'';
 const [co,sh,li]=COLORS[kind],S=A.S||(side==='R'?[-132,182]:[122,185]),E=A.E,W=A.W;
 const cuff=point(E,W,A.cuff===undefined?.24:A.cuff),mid=point(cuff,W,.5);
 if(layer==='body')return ribbon(S,E,cuff,39,29,24,co)+p(`M${f(E[0]-15)},${f(E[1]-15)}q25,16 34,17M${f(E[0]-15)},${f(E[1]-7)}l22,12`,'none',sh,2.2);
 let h='';
 if(A.shadow)h+=`<ellipse cx="${f(W[0]+22)}" cy="${f(W[1]+12)}" rx="40" ry="5" fill="#243c4d" opacity=".14"/>`;
 h+=ribbon(cuff,mid,W,24,21,16,skin);
 let angle=Math.atan2(W[1]-cuff[1],W[0]-cuff[0])*180/Math.PI-90;
 h+=`<g transform="translate(${f(cuff[0])},${f(cuff[1])}) rotate(${f(angle)})">`+p('M-24,-4L24,-4L24,7Q0,11 -24,7Z',li,ink,1.8)+'</g>';
 if(A.type==='grip')h+=grip(...W,A.handAngle||0);
 else if(A.type==='loose')h+=loose(...W,side==='L');
 else if(A.type==='support')h+=palmUp(...W);
 else h+=hand(...W,A.k===undefined?1:A.k,A.handAngle||0);
 return h;
}
function figure(kind,P,t,layer='body'){
 P.R=P.R?{...P.R,S:G.bodyPoint(P,[-132,182])}:null;P.L=P.L?{...P.L,S:G.bodyPoint(P,[122,185])}:null;
 let s='';
 if(layer==='body'){
  s+=arm(kind,'R',P.R,'body')+arm(kind,'L',P.L,'body')+coat(kind,P);
  const opt={yaw:P.yaw||0,pitch:P.pitch||0,gaze:P.gaze===undefined?(kind==='fin'?.7:-.7):P.gaze,smile:P.smile||0,alarm:P.alarm||0,hurt:P.hurt||0,concern:P.concern||0,talk:mouth(kind,t),viseme:viseme(kind,t),headvelocity:P.headVelocity||0,blink:P.blink};
  const H=G.bodyPoint(P,[0,0]);let head=Faces.head(kind,t,opt);
  s+=`<g transform="translate(${f(H[0]+(P.headX||0))},${f(H[1]+(P.headY||0))}) rotate(${f(P.headAngle||0)})">${head}</g>`;
 }else s+=arm(kind,'R',P.R,'hands')+arm(kind,'L',P.L,'hands');
 return `<g transform="${xf(P)}">${s}</g>`;
}
function shoe(x,y,flip=1,roll=0){return `<g transform="translate(${f(x)},${f(y)}) rotate(${f(roll)}) scale(${flip*.76},.76)">`+p('M-31,-20L17,-22Q25,-7 43,-6L70,3Q79,8 74,18L-30,18Q-42,14 -38,3Z','#344b60',ink,3.5)+p('M-35,11L73,11M-12,-12l24,8M-16,-4l23,7','none','#90a1ad',1.7)+'</g>'}
function legs(P,H1,K1,F1,H2,K2,F2){let s='';for(const [H,K,F,flip]of[[H2,K2,F2,-1],[H1,K1,F1,1]]){s+=ribbon(H,K,F,33,29,19,'#4b6073')+p(`M${f(K[0]-13)},${f(K[1]-7)}q18,-8 36,0M${f(H[0]+8)},${f(H[1]+20)}L${f(K[0]+5)},${f(K[1]-20)}`,'none','#81919e',2)+shoe(F[0],F[1],flip)}return s}
function normal(kind,t){let fin=kind==='fin';return{x:fin?660:1215,y:fin?386:377,s:1,R:{E:fin?[-180,331]:[-170,330],W:fin?[-96,432]:[-90,435],shadow:true,handAngle:8},L:{E:fin?[163,326]:[174,330],W:fin?[239,423]:[151,431],shadow:true,handAngle:-5},gaze:fin?.6:-.6,smile:.15}}
function guard(P,progress=1){
 P.L={E:point(P.L.E,[175,315],progress),W:point(P.L.W,[0,340],progress),type:'loose'};
 P.R={E:point(P.R.E,[-165,370],progress),W:point(P.R.W,[35,375],progress),type:'support'};
 return P;
}
function dust(t,strength){let s='';for(let i=0;i<6;i++){let x=1640-i*155+(t*10)%25,y=680+i%2*50;let a=strength*(.12-i*.011);s+=p(`M${x-180},${y}C${x-170},${y-78} ${x-55},${y-94} ${x-8},${y-52}C${x+53},${y-99} ${x+180},${y-25} ${x+150},${y+42}C${x+51},${y+90} ${x-97},${y+50} ${x-180},${y}Z`,'#a3adb6','none',0,`opacity="${f(a)}"`)}return s}
function chips(t){let s='';for(let i=0;i<14;i++){let start=4.22+i*.045,q=clamp((t-start)/1.25);if(q<=0||t>7)continue;let x=mix(1840-i*9,1580-i*23,q),y=400+i*13+q*q*(520-i*10);s+=prop(i%5===0?'prop-stone-slab':'prop-stone-chip',x,y,.35+(i%4)*.12,q*120+i*37)}
 let q=clamp((t-4.75)/.48);if(t>4.75&&t<5.23)s+=prop('prop-stone-chip',mix(1780,1387,q),mix(420,730,q)+q*q*30,.48,q*160);
 if(t>=5.2&&t<5.45)s+=`<circle cx="1387" cy="730" r="${f(8+(t-5.2)*65)}" fill="#aeb6bb" opacity="${f(.35*(1-(t-5.2)/.25))}"/>`;
 return s;
}
let bgNormal,bgDamaged;
function bg(which){return `<image x="0" y="0" width="1920" height="1080" href="data:image/png;base64,${which==='damaged'?bgDamaged:bgNormal}"/>`}
function sceneOld(t){
 let s='',camera='',shot=1;
 if(t<4){
  s=bg('normal')+C.actor('fin',t)+C.actor('zei',t)+C.desk()+C.actor('fin',t,'hands')+C.actor('zei',t,'hands');
 }else if(t<8){
  shot=2;let reveal=at(t,4.25,4.7),z=normal('zei',t),fin=normal('fin',t),flinch=at(t,4.13,4.23)*(1-at(t,4.6,4.95)),pain=at(t,5.18,5.42),fall=at(t,6.35,7.4);
  s=bg('normal')+`<g opacity="${f(reveal)}">${bg('damaged')}</g>`;
  z.y+=flinch*15+fall*620;z.x+=fall*72;z.angle=-flinch*4+fall*13;z.headAngle=flinch*6+pain*8;z.alarm=.8*(1-pain);z.hurt=pain*.8;z.smile=0;z.drop=flinch*12;
  z=guard(z,pain);fin.alarm=flinch*.9;fin.concern=at(t,4.5,5.2);fin.smile=0;fin.headAngle=at(t,4.4,4.9)*5;fin.gaze=1;
  let reach=at(t,5.6,6.3);fin.L={E:point([163,326],[260,255],reach),W:point([239,423],[425,365],reach),k:1,type:reach>.5?'grip':undefined};
  s+=prop('prop-chair-upright',1230+fall*70,850+fall*120,1,fall*47)+figure('fin',fin,t)+figure('zei',z,t)+C.desk()+figure('fin',fin,t,'hands')+figure('zei',z,t,'hands')+chips(t)+dust(t,reveal*.8);
  if(t<4.6){let amp=7*(1-clamp((t-4.12)/.48));camera=`translate(${f(Math.sin(t*97)*amp)},${f(Math.cos(t*83)*amp*.6)})`}
 }else if(t<13){
  shot=3;let lift=at(t,9.85,11.75),settle=at(t,11.75,12.45),enter=at(t,8,8.75),z={x:mix(1235,1260,lift),y:mix(590,345,lift)+settle*45,s:.68,angle:mix(-7,0,lift),headAngle:5,smile:0,hurt:.75-lift*.35,concern:.5,gaze:-.8,R:{E:[-205,405],W:[-230,610],shadow:true},L:{E:[175,315],W:[0,340],type:'loose'}};
  let Rmove=at(t,9.7,10.5);z.R={E:point([-205,405],[-165,370],Rmove),W:point([-230,610],[35,375],Rmove),type:Rmove>.5?'support':undefined,shadow:Rmove<.15};
  let fin={x:mix(780,850,enter)+lift*8,y:mix(435,475,enter)-lift*126+settle*8,s:.70,angle:mix(7,2,lift),headAngle:5,smile:0,concern:.7,gaze:.9,R:{hidden:true},L:{E:[275,270],W:[400,330],type:'grip'}};
  const contact=world(z,[-138,230]);fin.L.W=local(fin,contact);fin.L.E=point([190,280],fin.L.W,.5);fin.L.handAngle=-15;
  let zh1=world(z,[-60,480]),zh2=world(z,[70,480]),fh1=world(fin,[-60,480]),fh2=world(fin,[70,480]);
  s=bg('damaged')+chair(1280,770,.98)+prop('prop-chair-overturned',1550,930,.77);
  s+=`<ellipse cx="1240" cy="1009" rx="230" ry="31" fill="#2b4154" opacity=".22"/><ellipse cx="880" cy="1034" rx="202" ry="24" fill="#2b4154" opacity=".2"/>`;
  let seated=at(t,11.25,12.4);
  let knee1=point(point([1110,990],[1220,860],lift),[1130,850],seated),knee2=point(point([1350,1000],[1310,860],lift),[1400,850],seated);
  let foot1=point([1078,1035],[1130,1035],seated),foot2=point([1435,1035],[1395,1035],seated);
  s+=legs(z,zh1,knee1,foot1,zh2,knee2,foot2);
  s+=legs(fin,fh1,point([775,981],[803,863],lift),[912,1030],fh2,point([1010,878],[1025,854],lift),[1035,1030]);
  s+=figure('fin',fin,t)+figure('zei',z,t)+figure('zei',z,t,'hands')+figure('fin',fin,t,'hands')+dust(t,.7-lift*.25);
 }else{
  shot=t<19?4:5;
  const close=t>=19, q=at(t,18.7,20),tiny=Math.sin(t*2.1)*1.15;
  let z={x:1160,y:380+tiny,s:.8,headAngle:3-2*q,smile:close?.18+at(t,20.7,22.8)*.4:0,hurt:.37-q*.15,concern:.25,gaze:-.75,R:{E:[-165,370],W:[35,375],type:'support'},L:{E:[175,315],W:[0,340],type:'loose'}};
  if(t>21.6&&t<22.7){z.gaze=mix(-.75,.65,Math.sin((t-21.6)/1.1*Math.PI));z.headAngle=3+Math.sin((t-21.6)/1.1*Math.PI)*3}
  let fin={x:740,y:360+tiny*.7,s:.8,headAngle:4,smile:close?.15+at(t,22,23.5)*.45:0,concern:.65-q*.5,gaze:.9,R:{E:[-170,330],W:[-120,455],type:'loose'},L:{E:[240,260],W:[380,210],type:'grip',handAngle:-8}};
  fin.L.W=local(fin,world(z,[-134,189]));fin.L.E=point([195,280],fin.L.W,.5);
  const teach={x:1530,y:406,s:.68,angle:-5,headAngle:-7,gaze:-.8,smile:.03,concern:.55,R:{E:[-235,300],W:[-330,355],type:'grip'},L:{E:[165,340],W:[118,450],type:'loose'}};
  const device=[1322,648];teach.R.W=local(teach,[device[0]+25,device[1]+21]);
  s=bg('damaged')+chair(755,792,1.05)+chair(1175,797,1.05)+prop('prop-chair-overturned',1740,947,.63);
  s+=legs(fin,world(fin,[-58,480]),[640,842],[662,1050],world(fin,[65,480]),[885,845],[891,1040]);
  s+=legs(z,world(z,[-58,480]),[1045,850],[1054,1052],world(z,[65,480]),[1315,850],[1310,1048]);
  if(!close)s+=legs(teach,world(teach,[-55,480]),[1490,900],[1460,1045],world(teach,[60,480]),[1620,904],[1670,1042])+figure('teacher',teach,t);
  s+=figure('fin',fin,t)+figure('zei',z,t)+figure('zei',z,t,'hands')+figure('fin',fin,t,'hands');
  if(!close)s+=figure('teacher',teach,t,'hands')+prop('prop-scanner',device[0],device[1],.56,-14);
  // The small watch alert is a visible two-pulse cue, not an unexplained overlay.
  if(t>14.25&&t<14.7){let alpha=Math.max(0,Math.sin((t-14.25)*Math.PI*8));s+=p('M1018,668q-12,-9 -6,-20M1027,666q-6,-8 -2,-15','none','#b2c9cc',2.8,`opacity="${f(alpha)}"`)}
  s+=dust(t,Math.max(.08,.55-at(t,18.8,22.5)*.47));
  if(close)camera='translate(-155,-85) scale(1.13)';
 }
 return {svg:`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1920" height="1080" viewBox="0 0 1920 1080"><defs>${propDefs}</defs><g transform="${camera}">${s}</g></svg>`,shot};
}
function scene(t){const {s,camera,shot}=Acting.build({p,f,ease,mix,point,at,C,figure,legs,world,local,bg,prop,chair,chips,dust,Table},t);return{svg:`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1920" height="1080" viewBox="0 0 1920 1080"><defs>${propDefs}</defs><g transform="${camera}">${s}</g></svg>`,shot}}
async function prepare(){
 fs.mkdirSync(QA,{recursive:true});
 const normalFile=path.join(ASSETS,'classroom-original.svg');
 bgNormal=(await sharp(normalFile).png().toBuffer()).toString('base64');
 bgDamaged=(await sharp(path.join(ASSETS,'background-damaged.svg')).png().toBuffer()).toString('base64');
}
async function stills(){
 const times=[0,3.5,4.35,5.35,6.6,8.4,9.6,10.7,11.7,12.6,14,15.9,17.55,19.4,21.8,23.6];let thumbnails=[];
 for(let i=0;i<times.length;i++){let t=times[i],sc=scene(t),name=`shot-${String(i+1).padStart(2,'0')}-${t.toFixed(2)}s`;fs.writeFileSync(path.join(ASSETS,name+'.svg'),sc.svg);let png=await sharp(Buffer.from(sc.svg)).png().toBuffer();fs.writeFileSync(path.join(QA,name+'.png'),png);thumbnails.push(await sharp(png).resize(480,270).png().toBuffer())}
 await sharp({create:{width:1920,height:1080,channels:3,background:'#233747'}}).composite(thumbnails.map((input,i)=>({input,left:i%4*480,top:Math.floor(i/4)*270}))).png().toFile(path.join(QA,'film-storyboard.png'));
}
async function render(){
 const test=process.argv.includes('--motion-test'),preview=process.argv.includes('--preview')||test,fps=preview?24:120,width=preview?1280:1920,height=preview?720:1080,duration=test?6:24,start=test?8:0;
 const filename=test?'The-Lesson-acting-test-picture.mp4':preview?'The-Lesson-review-picture-24fps.mp4':'The-Lesson-picture-120fps.mp4',out=path.join(ROOT,filename);
 const enc=spawn(FFMPEG,['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${width}x${height}`,'-framerate',String(fps),'-i','pipe:0','-an','-c:v','libx264','-threads','4','-preset','veryfast','-crf',preview?'20':'18','-pix_fmt','yuv420p','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
 const exit=new Promise((resolve,reject)=>{enc.once('exit',code=>code===0?resolve():reject(Error(`encoder:${code}`)));enc.once('error',reject)});enc.stdin.on('error',()=>{});
 let count=fps*duration;
 // Four bounded raster jobs preserve every timestamp, and are written in order.
 for(let base=0;base<count;base+=4){
  const batch=await Promise.all(Array.from({length:Math.min(4,count-base)},async(_,j)=>{
   let svg=scene(start+(base+j)/fps).svg,im=sharp(Buffer.from(svg));if(preview)im=im.resize(width,height);
   return im.ensureAlpha().raw().toBuffer();
  }));
  for(let j=0;j<batch.length;j++){
   const i=base+j;if(!enc.stdin.write(batch[j]))await new Promise(r=>enc.stdin.once('drain',r));
   if(i%fps===0)console.log(`Film ${preview?'preview':'master'}: ${i/fps}/${duration}s (${i}/${count})`);
  }
 }
 enc.stdin.end();await exit;console.log(out);
}
async function main(){await prepare();if(process.argv.includes('--stills'))return stills();await render()}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1});
module.exports={scene,prepare,stills,render};
