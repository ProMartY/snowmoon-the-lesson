// SPDX-License-Identifier: GPL-3.0-only
// ProMartY, with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
const fs=require('node:fs'),path=require('node:path'),sharp=require('sharp');
const film=require('./film.cjs');
(async()=>{
 const t=Number(process.argv[2]??19.5),out=path.resolve(process.argv[3]||'frame.png');
 if(!Number.isFinite(t)||t<0||t>=24)throw Error('Frame time must be between 0 and 24 seconds.');
 await film.prepare();
 await sharp(Buffer.from(film.scene(t).svg)).png().toFile(out);
 console.log(path.basename(out));
})().catch(e=>{console.error(e.message);process.exitCode=1});
