// SPDX-License-Identifier: GPL-3.0-only
// ProMartY, with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
// A supplied mix must have separately established recording/service rights.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const ffmpeg=process.env.FFMPEG||'ffmpeg';
const mix=process.argv[2],out=process.argv[3]||'The-Lesson-with-audio.mp4';
if(!mix){console.error('Usage: node assemble-audio.cjs <cleared-24s-mix.wav> [output.mp4]');process.exit(2)}
const picture=path.join(__dirname,'The-Lesson-picture-120fps.mp4');
if(!fs.existsSync(picture)||!fs.existsSync(mix)){
 console.error('Render the picture first and supply an existing, separately cleared mix.');process.exit(2);
}
const r=spawnSync(ffmpeg,['-y','-hide_banner','-loglevel','error','-i',picture,'-i',mix,'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-t','24','-metadata','title=The Lesson','-metadata','artist=ProMartY, with OpenAI Codex assistance','-metadata','comment=Snowmoon Chapter 2 by Vitalik Buterin. Original vector adaptation; GPL-3.0-only original materials.','-metadata:s:a:0','language=eng','-movflags','+faststart',out],{stdio:'inherit',windowsHide:true});
if(r.error){console.error(r.error.message);process.exit(1)}
process.exit(r.status??1);
