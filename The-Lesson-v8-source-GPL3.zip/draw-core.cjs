// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Original, editable SVG drawings and authored pose curves.
// No image/video generation model or generated raster reference is used here.
const fs = require('node:fs');
const path = require('node:path');
const sharp=require('sharp');
const { spawn } = require('node:child_process');
const ROOT = __dirname;
const FFMPEG=process.env.FFMPEG||'ffmpeg';
const ink='#263646', skin='#e4d7d2', skinShade='#b5afbe', skinLight='#f0e4dc';
const clamp=v=>Math.max(0,Math.min(1,v));
const ease=v=>{v=clamp(v);return v*v*(3-2*v)};
const mix=(a,b,t)=>a+(b-a)*t;
const f=v=>Number(v.toFixed(2));
const p=(d,fill='none',stroke=ink,w=3,extra='')=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
function rng(seed=73){return()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}}
function textile(id,d,color){
 let r=rng(id==='fincoat'?102:203),s=`<clipPath id="${id}">${p(d,'white','none',0)}</clipPath><g clip-path="url(#${id})" opacity=".15">`;
 for(let i=0;i<84;i++){let x=-180+r()*360,y=145+r()*350,l=4+r()*14;s+=p(`M${f(x)},${f(y)}q${f(l*.4)},${f(-2+r()*4)} ${f(l)},${f(-2+r()*4)}`,'none',color,.75)}
 return s+'</g>';
}
function ribbon(S,E,W,a,b,c,fill){
 // Anatomical two-bone contour: taper around the actual segment normals.
 // The earlier fixed +/-8px control offsets bowed even straight shins and
 // used a whole-limb normal at the knee, making the joint rubbery.
 const finite=P=>P.map(v=>Number.isFinite(+v)?+v:0);
 S=finite(S);E=finite(E);W=finite(W);
 const unit=(P,Q,fallback)=>{const x=Q[0]-P[0],y=Q[1]-P[1],l=Math.hypot(x,y);return l>1e-6?[x/l,y/l]:fallback};
 const fallback=unit(S,W,[0,1]),u0=unit(S,E,fallback),u1=unit(E,W,u0);
 const n0=[-u0[1],u0[0]],n1=[-u1[1],u1[0]];
 const add=(P,N,r)=>[f(P[0]+N[0]*r),f(P[1]+N[1]*r)];
 a=Math.max(.01,Math.abs(a||0));b=Math.max(.01,Math.abs(b||0));c=Math.max(.01,Math.abs(c||0));
 const sum=[n0[0]+n1[0],n0[1]+n1[1]],sl=Math.hypot(...sum);
 const bis=sl>1e-5?sum.map(v=>v/sl):n0;
 // Capped miter controls a rounded elbow/knee without a sharp spike at folds.
 const dot=Math.max(.015,bis[0]*n0[0]+bis[1]*n0[1]);
 const outerJoin=Math.min(b/dot,b*1.28);
 const shortest=Math.min(Math.hypot(E[0]-S[0],E[1]-S[1])||1e6,Math.hypot(W[0]-E[0],W[1]-E[1])||1e6);
 const innerJoin=Math.min(b/dot,shortest*.88);
 const turn=u0[0]*u1[1]-u0[1]*u1[0];
 const A=add(S,n0,a),B0=add(E,n0,b),B1=add(E,n1,b),J=add(E,bis,outerJoin),I=add(E,bis,innerJoin);
 const C=add(W,n1,c),D=add(W,n1,-c),F1=add(E,n1,-b),F0=add(E,n0,-b),K=add(E,bis,-outerJoin),H=add(E,bis,-innerJoin),G=add(S,n0,-a);
 // The concave side meets at its segment intersection. Rounding both sides
 // through E made sharply bent elbows self-intersect like a tied ribbon.
 const left=turn>.0001?`L${I}`:`L${B0} Q${J} ${B1}`;
 const right=turn<-.0001?`L${H}`:`L${F1} Q${K} ${F0}`;
 return p(`M${A} ${left} L${C} L${D} ${right} L${G} Z`,fill,ink,3.5);
}
const handD='M-20,12 Q-29,-13 -29,-39 L-40,-58 Q-45,-69 -38,-73 Q-31,-77 -24,-59 L-19,-50 L-22,-103 Q-22,-114 -14,-114 Q-7,-114 -8,-102 L-7,-64 L-6,-124 Q-5,-136 3,-135 Q11,-133 10,-123 L9,-63 L13,-116 Q17,-127 23,-122 Q29,-119 25,-108 L24,-58 L31,-91 Q35,-101 41,-96 Q48,-92 44,-81 L36,-43 Q31,-17 23,-3 L18,15 Z';
function hand(x,y,k,extra=0){
 // One continuous contour for the whole raised-to-rest perspective change;
 // the former k=.78 construction switch produced an instantaneous palm pop.
 k=clamp(k);let i=0,coords=[];
 handD.replace(/-?\d+(?:\.\d+)?/g,v=>{coords.push(+v);return v});
 const warped=handD.replace(/-?\d+(?:\.\d+)?/g,()=>{const j=Math.floor(i/2),xx=coords[j*2],yy=coords[j*2+1];const out=i%2===0?xx*(1-.55*k)-yy*.66*k:yy*(1-.92*k)+xx*.36*k;i++;return f(out)});
 let s=`<g transform="translate(${f(x)},${f(y)}) rotate(${f(extra)})">`+p(warped,skin,ink,2.8);
 // Creases use absolute coordinates and the same projection as the silhouette.
 const crease=(X,Y)=>[f(X*(1-.55*k)-Y*.66*k),f(Y*(1-.92*k)+X*.36*k)];
 for(const [A,B,C]of[[[-18,-41],[-3,-50],[10,-43]],[[-18,-16],[-5,-24],[12,-17]],[[-20,-78],[-15,-81],[-8,-79]],[[-5,-80],[0,-84],[8,-81]],[[15,-78],[20,-81],[25,-77]]])s+=p(`M${crease(...A)} Q${crease(...B)} ${crease(...C)}`,'none','#9d929f',1.4);
 s+=p(`M${crease(-22,-29)} Q${crease(-25,-12)} ${crease(-14,0)}`,'none',skinLight,2.5);
 return s+'</g>';
}
function face(kind,t,opts={}){
 let fin=kind==='fin';
 let response=ease((t-1.85)/.62),relief=ease((t-2.65)/.60),look=fin?response:ease((t-.45)/.4),turn=look*(fin?14:-15),smile=fin?response:relief;
 let alarm=opts.alarm||0, hurt=opts.hurt||0, concern=opts.concern||0, talk=clamp(opts.talk||0);
 if(opts.gaze!==undefined)turn=opts.gaze*12;
 if(opts.smile!==undefined)smile=opts.smile;
 let blink=0;for(const st of(fin?[.17,2.85]:[.62,3.5])){let q=Math.abs(t-st);blink=Math.max(blink,Math.max(0,1-q/.075))}
 if(hurt>.25)blink*=.1;
 let eyeOpen=(1-blink*.94)*(1+alarm*.3-hurt*.42);
 let jaw=fin?7:0;
 let d=`M-94,-73 C-93,-129 -43,-148 19,-141 C78,-138 106,-96 99,-42 L95,37 Q89,99 ${f(39+turn)},${f(127+jaw)} Q${f(7+turn)},146 -26,130 Q-62,116 -85,71 L-99,12 C-117,-5 -118,-42 -108,-53 Q-99,-63 -94,-52Z`;
 let s=p(d,skin,ink,3.6);
 s+=p('M-89,-58 Q-62,-114 -16,-122 Q42,-128 83,-83 Q82,-47 91,-12 L84,56 Q63,105 29,124 Q-21,133 -54,103 Q-18,126 12,106 Q57,80 67,31 L65,-55 Q19,-91 -31,-74Z',skinShade,'none',0,'opacity=".25"');
 s+=p('M-101,-31 Q-124,-53 -120,-10 Q-120,19 -99,24 L-89,15',skin,ink,2.8)+p('M-105,-21q-10,-8 -9,8q1,10 9,10','none','#9d939f',1.9);
 s+=p('M-66,41 Q-49,34 -28,43 Q-39,64 -59,58Z','#c9aeb8','none',0,'opacity=".22"');
 s+=p('M43,37 Q62,26 79,37 L70,55 Q56,59 47,48Z','#c9aeb8','none',0,'opacity=".20"');
 let gaze=opts.gaze!==undefined?opts.gaze*8:(fin?(2+look*7):(-7-look*2));
 for(let [cx,w,ey] of(fin?[[-43,28,-10],[44,25,-14]]:[[-43,27,-12],[42,24,-10]])){
 if((fin&&cx>0)||(!fin&&cx<0))w*=1-look*.22;
 let ox=cx+turn*.35,eh=11*eyeOpen;
 s+=p(`M${f(ox-w)},${ey} Q${f(ox)},${f(ey-eh)} ${f(ox+w)},${ey} Q${f(ox+2)},${f(ey+eh*.85)} ${f(ox-w)},${ey}Z`,'#ecece3',ink,1.7);
 if(eyeOpen>.25){s+=`<ellipse cx="${f(ox+gaze)}" cy="${ey+.5}" rx="7.6" ry="${f(8.5*eyeOpen)}" fill="${fin?'#6d777b':'#63767a'}"/><ellipse cx="${f(ox+gaze)}" cy="${ey+.7}" rx="3.3" ry="${f(5.5*eyeOpen)}" fill="#263745"/><circle cx="${f(ox+gaze-2)}" cy="${ey-2.5}" r="1.5" fill="#edf4ee"/>`}
 s+=p(`M${f(ox-w)},${ey} Q${f(ox)},${f(ey-eh)} ${f(ox+w)},${ey}`,'none',ink,3.2);
 s+=p(`M${f(ox-w+3)},${ey+17}q20,7 38,0`,'none','#b2a4ae',1.25,'opacity=".65"');
 }
 s+=p(`M-73,${f(-39-response*3-alarm*8)} Q-46,${f(-51-response*9-alarm*15)} -20,${f(-40-response*2-concern*12+hurt*8)} M23,${f(-38+smile*2-concern*12+hurt*8)} Q46,${f(-48+smile*2-alarm*13)} 69,${f(-37-alarm*7)}`,'none',fin?'#61544e':'#323a41',5.8);
 s+=p(`M${f(7+turn)},-10 Q${f(10+turn)},10 ${f(22+turn)},25 Q${f(9+turn)},33 ${f(-1+turn)},27`,'none','#a79ca8',2.4);
 s+=p(`M${f(8+turn)},6 L${f(19+turn)},23 L${f(6+turn)},26Z`,'#d3bfc2','none',0);
 let my=77-smile*3;
 if(talk>.07||alarm>.4){
  let opening=Math.max(2,talk*20,alarm*8),w=23+talk*8;
  s+=p(`M${f(turn-w)},${f(my-2)} Q${f(turn+3)},${f(my-5)} ${f(turn+w)},${f(my-3-smile*5)} Q${f(turn+w-4)},${f(my+opening+5)} ${f(turn+3)},${f(my+opening+5)} Q${f(turn-w+1)},${f(my+opening+2)} ${f(turn-w)},${f(my-2)}Z`,'#61535f','#7f6974',2.2);
  if(talk>.20&&hurt<.25)s+=p(`M${f(turn-w+4)},${f(my-1)} Q${f(turn+3)},${f(my-3)} ${f(turn+w-4)},${f(my-2)} L${f(turn+w-6)},${f(my+3)} Q${f(turn)},${f(my+6)} ${f(turn-w+6)},${f(my+3)}Z`,'#e7e4d9','none',0);
 }else s+=p(`M${f(-26+turn)},${f(my+hurt*4)} Q${f(9+turn)},${f(my+12-smile*12-hurt*14)} ${f(39+turn)},${f(my-4-smile*6+hurt*7)}`,'none','#7f6974',2.6);
 s+=p(`M${f(-12+turn)},${f(my+17)}q16,4 28,-2`,'none','#b7a4ae',1.6);
 if(smile>.15)s+=p(`M${f(35+turn)},${f(my-7-smile*4)}q7,0 8,7`,'none','#b09aab',1.3);
 s+=p('M-53,102q11,11 20,11 M38,106l-9,7','none','#eae0d9',2.3);
 if(fin){for(const [x,y,r]of[[-64,24,1.7],[-55,29,1.3],[-44,25,1.6],[-35,32,1.3],[48,24,1.5],[59,26,1.3],[67,22,1.6]])s+=`<circle cx="${x}" cy="${y}" r="${r}" fill="#a39195" opacity=".63"/>`}
 return s;
}
function hair(kind,t){
 let fin=kind==='fin',lag=Math.sin(t*3.7)*.65+(fin?ease((t-1.93)/.65):ease((t-.62)/.6))*.5;
 if(fin){
 let s=p(`M-108,10 C-129,-11 -133,-42 -119,-63 C-145,-93 -122,-123 -98,-124 C-103,-151 -77,-168 -51,-157 C-34,-185 1,-178 10,-166 C37,-185 66,-166 69,-150 C101,-157 124,-130 115,-111 C138,-93 126,-68 109,-59 Q113,-25 94,-8 L81,-60 Q50,-71 34,-104 Q6,-76 -21,-88 Q-38,-53 -69,-64 L-88,-22 L-95,15Z`,'#68574f',ink,4.1);
 s+=p('M-117,-60 C-91,-61 -90,-99 -65,-105 Q-83,-67 -53,-71 Q-23,-82 -17,-112 Q-13,-83 9,-98 Q27,-116 35,-128 Q30,-103 48,-95 Q71,-80 91,-82 L97,-35 L85,-60 Q55,-72 34,-104 Q5,-76 -21,-88 Q-38,-53 -69,-64 L-88,-22 L-95,15 L-108,10Z','#4c4b4d','none',0);
 for(const d of['M-98,-125q-26,14 -10,33q9,8 17,-4','M-54,-151q-26,-6 -32,17q-3,14 11,13','M-11,-157q-23,-6 -27,11q-5,16 11,17','M34,-154q-18,-9 -26,5q-7,15 9,17','M68,-139q-15,-5 -20,7q-4,14 7,18','M96,-116q-15,-9 -19,3q-6,12 6,16','M-67,-101q7,-21 21,-15','M-6,-111q8,-23 24,-23'])s+=p(d,'none','#a39585',2.6);
 s+=p('M-113,-72q-9,8 -5,19 M-79,-140q7,-7 16,-3 M20,-160q10,1 14,8 M79,-126l10,4','none','#c0afa0',1.5,'opacity=".7"');
 return `<g transform="translate(0,${f(lag)})">${s}</g>`;
 }
 let s=p(`M-106,11 Q-123,-21 -114,-54 L-120,-67 L-105,-77 L-111,-105 L-88,-103 L-83,-133 L-57,-127 L-34,-159 L-10,-146 L17,-162 L34,-144 L70,-153 L77,-129 L104,-128 L100,-103 L120,-88 L106,-63 L109,-37 L94,12 L81,1 L78,-48 L65,-62 Q28,-49 3,-79 Q-19,-51 -51,-64 L-68,-40 L-80,-43 L-94,13Z`,'#36424c',ink,4.2);
 s+=p('M-104,-80 Q-65,-137 -3,-125 Q41,-123 90,-106 L80,-88 Q32,-97 4,-79 Q-22,-54 -51,-64 L-68,-40 L-80,-43 L-94,13 L-106,11Z','#293642','none',0);
 for(const d of['M-88,-102q19,-16 39,-20','M-45,-124q16,-7 28,-5','M-12,-126q25,-7 40,-5','M25,-130q21,0 37,6','M67,-121l18,12','M-83,-77q10,-14 24,-17','M-43,-78q18,-9 27,-19','M29,-91q20,-8 38,-5','M88,-67l-2,23'])s+=p(d,'none','#6e7f89',2.1);
 return `<g transform="translate(0,${f(lag)})">${s}</g>`;
}
function actor(kind,t,mode='body'){
 let fin=kind==='fin',down=ease((t-.78)/.87),resp=ease((t-1.85)/.65),relief=ease((t-2.65)/.6);
 let by=Math.sin(t*2.3)*1.2+(fin?0:down*9+relief*3),bx=fin?resp*3:-down*4;
 let hx=fin?660:1215,hy=fin?386:365;
 let coat=fin?'#687f94':'#82938a',shade=fin?'#465d73':'#596e6c',light=fin?'#92a2ae':'#a2b0a1';
 let body=`M-53,121 Q-76,150 -136,166 Q-172,178 -181,228 L-167,412 L-136,487 Q-45,506 101,486 L159,450 L177,239 Q164,183 111,165 L48,130 Q2,161 -53,121Z`;
 let S=[-132,182+by],E,W;
 if(fin){E=[-180,331];W=[-96,432]}
 else {let q=down;E=[mix(-225,-170,q)-Math.sin(q*Math.PI)*9,mix(164,330,q)];W=[mix(-255,-90,q)-Math.sin(q*Math.PI)*48,mix(-36,435,q)]}
 let s=`<g transform="translate(${f(hx+bx)},${f(hy+by)})">`;
 // Contact shadow, far arm and the changing near-arm outline.
 if(fin)s+=p('M-132,185 Q-173,199 -183,249 L-205,350 Q-182,397 -118,425 L-77,412 L-139,338 L-114,233Z',coat,ink,3.6);
 if(fin)s+=ribbon([120,187],[163,326],[239,423],39,32,21,coat);
 else s+=ribbon([115,184],[174,330],[151,431],37,30,22,coat);
 if(!fin){s+=ribbon(S,E,W,43,31,17,coat)}
 s+=p(body,coat,ink,4.4);
 s+=p('M-28,159 Q-12,190 29,181 L64,174 L87,482 Q19,490 -33,483 L-51,192Z',fin?'#394b5b':'#b9c4c2',ink,2.6);
 s+=p('M-151,193 Q-115,210 -107,284 L-134,462 L-163,410 L-173,238Z',shade,'none',0,'opacity=".72"');
 s+=p('M106,182 Q134,225 140,292 L116,469 L149,448 L173,239 Q155,195 106,182Z',shade,'none',0,'opacity=".72"');
 s+=p('M-52,139 L-78,168 L-33,218 L-8,177 L-31,153Z',light,ink,2.5);
 s+=p('M47,140 L82,169 L49,218 L23,179 L43,160Z',light,ink,2.5);
 s+=p('M-40,215 L-28,475 M51,219 L66,478','none',ink,2.0);
 s+=p('M-102,229 L-56,233 L-51,300 Q-76,315 -105,300Z',fin?'#6f869a':'#8a9d90',ink,2.3);
 s+=p('M-103,234 L-56,238 M-96,292l30,3','none',light,1.4);
 s+=p('M81,242 Q107,258 104,297 M-134,265 Q-113,286 -117,318 M-122,366l-12,37 M89,372q21,33 14,70 M-20,457q19,-9 40,-1 M-131,468q47,14 77,10','none',shade,3.4);
 s+=p('M-128,257q9,26 6,43 M98,323l-8,22 M-100,420q17,-11 24,-8 M77,444l10,16','none',light,1.6);
 for(let y=259;y<472;y+=65)s+=`<circle cx="58" cy="${y}" r="3.9" fill="#bfcbca" stroke="${ink}" stroke-width="1.3"/><path d="M56,${y-1}l4,2" stroke="#667c83" stroke-width="1"/>`;
 s+=textile(fin?'fincoat':'zeicoat',body,fin?'#dae2e3':'#dee7d9');
 // Collarbone and neck are separately redrawn above the coat.
 s+=p('M-42,108 L-48,149 Q-22,188 23,176 L49,145 L36,108Z',skin,ink,3.0);
 s+=p('M-42,111 L35,111 L34,137 Q8,157 -35,151Z',skinShade,'none',0,'opacity=".55"');
 s+=p('M-24,156q15,6 29,1','none','#b1a2ae',1.8);
 // Forearm and palm follow the changing arc, rather than a rigid cutout.
 let hands='';
 if(!fin){
 let q=down;let cuff=[mix(E[0],W[0],.24),mix(E[1],W[1],.24)];
 if(q>.93)hands+=`<ellipse cx="${f(W[0]+25)}" cy="${f(W[1]+20)}" rx="48" ry="9" fill="#243c4d" opacity=".22"/>`;
 hands+=ribbon(cuff,[mix(cuff[0],W[0],.5),mix(cuff[1],W[1],.5)],W,24,21,16,skin);
 hands+=p(`M${f(cuff[0]-24)},${f(cuff[1]+4)} Q${f(cuff[0])},${f(cuff[1]-8)} ${f(cuff[0]+24)},${f(cuff[1]+3)}`,'none',light,7);
 hands+=p(`M${f(E[0]-18)},${f(E[1]-16)} Q${f(E[0]+8)},${f(E[1]+4)} ${f(E[0]+22)},${f(E[1]+9)} M${f(E[0]-16)},${f(E[1]-9)}l22,12`,'none',shade,2.1);
 hands+=hand(W[0],W[1],q,(-6*(1-q)));
 }else{
 hands+='<ellipse cx="266" cy="440" rx="46" ry="8" fill="#243c4d" opacity=".22"/><ellipse cx="-70" cy="452" rx="45" ry="8" fill="#243c4d" opacity=".2"/>';
 hands+=ribbon([193,397],[216,413],[239,423],23,20,17,skin)+hand(239,423,1,-5);
 hands+=ribbon([-137,395],[-118,416],[-96,432],22,20,16,skin)+hand(-96,432,1,8);
 }
 if(!fin){hands+='<ellipse cx="176" cy="453" rx="45" ry="8" fill="#243c4d" opacity=".2"/>'+ribbon([149,398],[151,416],[151,432],22,20,15,skin)+hand(151,432,1,9)}
 let headShiftX=fin?resp*2:-ease((t-.45)/.4)*3;
 let headShiftY=fin?-resp*2:relief*2;
 if(mode==='hands')return `<g transform="translate(${f(hx+bx)},${f(hy+by)})">${hands}</g>`;
 s+=`<g transform="translate(${f(headShiftX)},${f(headShiftY)}) rotate(${f(fin?resp*3:-ease((t-.45)/.4)*3)})">${face(kind,t)}${hair(kind,t)}</g>`;
 return s+'</g>';
}
function desk(){
 let s=p('M218,811 L1558,811 L1718,915 L104,915Z','#8a949d',ink,4.5);
 s+=p('M218,811 L1558,811 L1687,894 L137,894Z','#b6bcc0',ink,2.2);
 s+=p('M104,915 L1718,915 L1710,1010 L115,1010Z','#596d7e',ink,4.2);
 s+=p('M116,925 Q450,931 793,926 T1708,926 M121,1000Q700,1004 1707,1000','none','#8396a2',2);
 s+=p('M210,947L1617,947 M391,951v43 M1397,949v47','none','#465e72',2.7);
 let r=rng(82);for(let i=0;i<43;i++){let x=190+r()*1380,y=839+r()*38;s+=p(`M${f(x)},${f(y)}l${f(8+r()*38)},${f(r()*3-1.5)}`,'none','#7c8b95',1.0,'opacity=".5"')}
 // Paper, pen and a personally drawn lesson diagram.
 s+=p('M574,818 L787,816 L839,864 L600,871Z','#e1e4dc','#586d7c',1.8);
 s+=p('M597,828l148,-1 M605,835l107,0 M617,846l50,-1 M720,840l55,13 M720,853l54,-14','none','#82939b',1.25);
 s+=p('M856,851l93,-11 l4,4 l-92,12Z','#354859',ink,1.2);
 return s;
}
function foreground(t){return `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">${actor('fin',t)}${actor('zei',t)}${desk()}${actor('fin',t,'hands')}${actor('zei',t,'hands')}</svg>`}

module.exports={p,f,ease,mix,clamp,rng,ribbon,hand,face,hair,textile,desk,actor,ink,skin,skinShade,skinLight};
