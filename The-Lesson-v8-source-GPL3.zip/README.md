# The Lesson

**Public film: English captions with recorded CC0 sound effects; no spoken voices.**

The released film is distributed separately as `The-Lesson-CC0-SFX-English-captions-1080p120.mp4`. This archive contains the editable production materials and CC0 effects inputs.

![The Lesson — original vector adaptation](assets/poster.png)

An original editable 2D vector short adapting the classroom incident in *Snowmoon*, Chapter 2, by Vitalik Buterin. Adaptation production: ProMartY, with OpenAI Codex assistance. **GPL-3.0-only**; see [ATTRIBUTION.md](ATTRIBUTION.md) and [LICENSE.txt](LICENSE.txt).

The picture is 24 seconds, 1920×1080 at 120 frames/second. Every frame samples authored pose curves and vector deformations at its timestamp. This is code-assisted vector animation, not a frame-by-frame drawing made by a human animator. It uses no neural image/video generation or optical-flow interpolation in the final picture.

## Render

Install Node.js 22 or later and FFmpeg with the `libx264` encoder. Put FFmpeg on your PATH, or set the `FFMPEG` environment variable to its executable. Then, from this folder:

```sh
npm install
npm run stills
npm run preview
npm run render
```

`stills` writes representative SVG drawings under `assets/` and a contact sheet under `qa/`. `preview` renders a 1280×720/24fps silent review. `render` writes `The-Lesson-picture-120fps.mp4` at 1920×1080/120fps. Four bounded raster jobs run concurrently; encoded frames remain in timestamp order. Rendering needs memory and CPU time; no paid service or subscription is called.

For one frame:

```sh
node render-frame.cjs 19.5 frame.png
```

## Source layout

- `assets/*.svg`: original editable classroom, contained damage into an adjoining underground room, and props.
- `draw-core.cjs`, `acting-geometry.cjs`, `facial-acting.cjs`: contours, limbs, clothing deformation and approximate head projection.
- `scene-acting.cjs`, `film.cjs`: shot timing, contact poses, staging and rendering.
- `props-table.cjs`: projected table, paper and pen.
- `DIALOGUE.json`, `The-Lesson-EN.srt`: condensed English script and timing.
- `timing/`: measured speech-amplitude activity and approximate word/spelling-derived mouth shapes. These are not forced-aligned phonemes.
- `assets/poster.png`: actual poster extracted from the final picture.
- `audio/`: CC0 effects mix, used source clips and licensing/provenance.
- `assemble-captions.cjs`: portable subtitle/effects assembly.
- `PRODUCTION.md`: creative brief, tool use and known limitations.
- `audio-reference/`: explicitly disabled-by-default historical audio harnesses and CC0 sound recipe; no recordings or service rights are bundled.

## Audio assembly

The released cut uses the included recorded CC0 foley mix and burned-in English captions, without speech. After rendering the picture, run:

```sh
node assemble-captions.cjs
```

This writes `The-Lesson-CC0-SFX-English-captions-1080p120.mp4`. The original caption family was Arial at 23 pt, outline 2 and vertical margin 32. No Arial font file is bundled; install a font you may use, or set `CAPTION_FONT` to an available family such as Noto Sans. FFmpeg may substitute a font on another platform. The exact release movie is supplied separately; re-encoding or a substitute installed caption font may produce different bytes. Source clips, license notices, original-source links and hashes are under `audio/`. The picture render and caption assembly make no online service calls.

Historical generated-voice reference harnesses are disabled by default and are not used to assemble the released film. No TTS or speech recordings are included. For an optional future soundtrack, supply a separately cleared 24-second mix and run:

```sh
node assemble-audio.cjs audio-input/mix.wav The-Lesson-with-audio.mp4
```

This command copies the rendered H.264 picture and encodes the supplied mix as AAC stereo. It does not obtain a recording license. The generated-voice reference is excluded from this release because its redistribution rights were not established.
