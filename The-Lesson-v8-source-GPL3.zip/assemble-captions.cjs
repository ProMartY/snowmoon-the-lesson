// SPDX-License-Identifier: GPL-3.0-only
// ProMartY with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
// Approved release format: English captions + recorded CC0 effects, no speech.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const ffmpeg=process.env.FFMPEG||'ffmpeg',root=__dirname;
const font=process.env.CAPTION_FONT||'Arial';
if(!/^[A-Za-z0-9 _()-]+$/.test(font))throw Error('Use a plain installed font family name.');
const inputs=['The-Lesson-picture-120fps.mp4','audio/The-Lesson-CC0-foley-24s.wav','audio/English-dialogue.srt'];
for(const p of inputs)if(!fs.existsSync(path.join(root,p)))throw Error('Missing input: '+p);
const out=process.argv[2]||'The-Lesson-CC0-SFX-English-captions-1080p120.mp4';
const style=`Fontname=${font},Fontsize=23,Outline=2,MarginV=32`;
const r=spawnSync(ffmpeg,['-y','-hide_banner','-loglevel','error','-i',inputs[0],'-i',inputs[1],'-map','0:v:0','-map','1:a:0','-vf',`subtitles=${inputs[2]}:force_style='${style}'`,'-c:v','libx264','-preset','veryfast','-crf','18','-threads','4','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-t','24','-movflags','+faststart',out],{cwd:root,stdio:'inherit',windowsHide:true});
if(r.error){console.error(r.error.message);process.exit(1)}
process.exit(r.status??1);
