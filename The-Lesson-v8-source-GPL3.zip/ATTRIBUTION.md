# Attribution and licensing

**The Lesson** is a 24-second condensed adaptation of the classroom incident in Chapter 2 of *Snowmoon*, by **Vitalik Buterin**.

- Original novel and license notice: https://vitalik.eth.limo/snowmoon/
- Specific source scene: https://vitalik.eth.limo/snowmoon/html/chapter-2.html
- Adaptation and original production materials: **ProMartY, with OpenAI Codex assistance**.
- Original adaptation code, editable vectors, authored pose curves, dialogue adaptation, timing data and production notes in this source package: **GNU GPL version 3 only**, SPDX `GPL-3.0-only`.
- The complete unmodified GNU GPL v3 text is in `LICENSE.txt`.

The official novel landing page explicitly states: “Snowmoon is released under the GPL v3”. It also asks adaptations to open the task-specific pipeline and other important non-commodity production materials. This package therefore includes the editable set/prop drawings, character and acting code, shot staging, approximate mouth timing and render pipeline. The novel itself is linked, not bundled.

This condensed adaptation changes dialogue wording and timing, simplifies the cast and room, and uses original fictional character designs. Its opening praise is a complete sentence rather than the source novel's interrupted word. Zei's name is pronounced “Zay” in the private generated-voice reference; that pronunciation is not verified with the author.

The original author, OpenAI, voice provider and bounty organizer did not commission or endorse this adaptation. Authorship credit does not claim their approval or any contest result.

## Third-party software and recordings

Node.js, Sharp/libvips/librsvg and FFmpeg/libx264 are external tools with their own licenses; no executable, dependency source tree, model, font file or proprietary service credential is bundled or relicensed.

The public film and source package include **recorded CC0 sound effects and English captions, with no speech recording**. See `audio/licenses/SOURCE-NOTICES.md` and `audio/SOUND-MANIFEST.json` for authors, licensing scope and exact source hashes. The English text/timing files identify the generated voice reference used to time the picture. Any future separately distributed speech requires its own applicable rights. GPL licensing of the original picture materials does not establish redistribution rights in a third-party speech service output.
