// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Original staging and separately timed body/head/hand poses for The Lesson.
const G=require('./acting-geometry.cjs');
function build(A,t){
 const {p,f,ease,mix,point,at,C,figure,legs,world,local,bg,prop,chair,chips,dust,Table}=A;
 const T=G.track,B=G.pulse,AR=G.arc;
 const pt=(P,v)=>world(P,G.bodyPoint(P,v));
 function arm(P,side,W,opt={}){const S=G.bodyPoint(P,side==='R'?[-132,182]:[122,185]);return{E:G.elbow(S,W,opt.l1||185,opt.l2||195,opt.bend===undefined?(side==='R'?1:-1):opt.bend),W,...opt}}
 function reaching(P,side,W,opt={}){const S=G.bodyPoint(P,side==='R'?[-132,182]:[122,185]),E=point(S,W,.52);E[1]+=34;E[0]-=8;return arm(P,side,W,{...opt,E})}
 function base(kind){return{x:kind==='fin'?660:1215,y:kind==='fin'?385:377,s:1,angle:0,chestX:0,chestY:0,shoulderTilt:0,breath:Math.sin(t*1.5+(kind==='fin'?.6:2)),yaw:0,pitch:0,gaze:0,headAngle:0,smile:0,concern:0,hurt:0}}
 function tablePose(kind){
  let P=base(kind),isF=kind==='fin',look=at(t,1.35,2.65),lower=at(t,.82,2.15);
  P.chestX=(isF?T(t,[[0,0],[1.2,-5],[2.4,8],[3.6,4]]):T(t,[[0,-4],[.9,-8],[1.9,5],[3.5,0]]));
  P.chestY=2*Math.sin(t*1.6+(isF?0:1.2));P.shoulderTilt=(isF?-1.4:1.4)*look;
  P.yaw=isF?T(t,[[0,-.25],[1.1,-.25],[1.7,.1],[2.35,.5],[3.5,.37]]):T(t,[[0,-.16],[.6,-.2],[1.65,-.35],[2.7,-.5],[3.8,-.36]]);
  P.gaze=isF?mix(-.25,.7,at(t,1.1,1.7)):-.55;
  P.headY=(isF?-5:4)*B(t,1.45,1.85,2.3);P.headAngle=(isF?4:-3)*look;
  P.pitch=(isF?.2:-.1)*(1-look);P.smile=isF?.12+.32*look:.2+.25*at(t,1.7,3);
  P.headVelocity=(isF?1.8:-1.3)*B(t,1.2,1.8,2.5);
  const tap=B(t,2.75,2.95,3.3);
  P.R=arm(P,'R',isF?[-96,432-8*tap]:AR([-255,-36],[-90,435],lower,80),{E:isF?[-180,331]:AR([-225,164],[-170,330],lower,12),handAngle:isF?8:-6*(1-lower),k:isF?1:lower,shadow:isF||lower>.95});
  P.L=arm(P,'L',isF?[239,423]:[151,432],{E:isF?[163,326]:[174,330],handAngle:-5,k:1,shadow:true});
  return P;
 }
 function guarded(P){P.L=arm(P,'L',[2,340],{E:[175,315],type:'loose'});P.R=arm(P,'R',[35,375],{E:[-165,370],type:'support'});return P}
 let s='',camera='',shot=1;
 if(t<4){
  const fin=tablePose('fin'),z=tablePose('zei');
  s=bg('normal')+figure('fin',fin,t)+figure('zei',z,t)+Table.desk()+figure('fin',fin,t,'hands')+figure('zei',z,t,'hands');
 }else if(t<8){
  shot=2;const impact=B(t,4.13,4.28,4.85),pain=at(t,5.15,5.45),fall=at(t,6.35,7.45),revealed=at(t,4.22,4.63);
  const fin=tablePose('fin'),z=tablePose('zei');
  z.chestX=T(t,[[4,0],[4.2,-22],[4.4,-40],[4.85,-12],[5.2,7],[5.45,28],[6.2,22],[6.8,46],[7.5,15]]);
  z.chestY=-18*impact+pain*11;z.shoulderTilt=-3*impact+6*pain;z.y+=fall*600;
  z.x+=fall*75;z.angle=fall*8;z.headAngle=T(t,[[4,-3],[4.18,7],[4.35,-8],[4.8,-3],[5.35,10],[5.85,5],[7.5,11]]);
  z.yaw=T(t,[[4,-.35],[4.15,.1],[4.55,.7],[5.2,.45],[5.55,-.1],[6.3,-.4],[7.8,-.2]]);z.gaze=mix(.8,-.75,pain);z.pitch=pain*.28;z.hurt=pain*.85;z.alarm=.9*impact;z.smile=0;
  z.headVelocity=2*B(t,4.1,4.27,4.65)-1.6*B(t,5.2,5.45,5.85);
  const L0=[151,432],L1=[2,340],R0=[-90,435],R1=[35,375];
  z.L=arm(z,'L',AR(L0,L1,pain,45),{E:point([174,330],[175,315],pain),type:pain>.35?'loose':undefined,k:1});z.R=arm(z,'R',AR(R0,R1,at(t,5.4,6.1),35),{E:point([-170,330],[-165,370],at(t,5.4,6.1)),type:t>5.8?'support':undefined,k:1});
  fin.chestX=T(t,[[4,4],[4.23,-17],[4.7,-3],[5.2,20],[6.1,54],[7.5,64]]);fin.chestY=-10*impact+at(t,5.2,6.3)*9;fin.shoulderTilt=-4*at(t,5.5,6.2);
  fin.headAngle=T(t,[[4,4],[4.3,-7],[4.8,3],[5.5,8],[6.5,11],[7.8,7]]);fin.yaw=T(t,[[4,.35],[4.3,.65],[5.3,.4],[6.5,.6]]);fin.gaze=.9;fin.alarm=.8*impact;fin.concern=at(t,4.65,5.5)*.75;fin.smile=0;
  fin.headVelocity=1.5*B(t,4.1,4.3,4.75);
  const reach=at(t,5.55,6.75);fin.L=reaching(fin,'L',AR([239,423],[445,365],reach,105),{bend:1,type:reach>.7?'grip':undefined,k:1,handAngle:-10});
  s=bg('normal')+`<g opacity="${f(revealed)}">${bg('damaged')}</g>`;
  s+=prop('prop-chair-upright',1230+fall*60,800+fall*80,.9,fall*45)+figure('fin',fin,t)+figure('zei',z,t);
  if(fall>.12)s+=figure('zei',z,t,'hands');
  s+=Table.desk()+figure('fin',fin,t,'hands');if(fall<=.12)s+=figure('zei',z,t,'hands');
  s+=chips(t)+dust(t,revealed*.75);
  if(t<4.6){const q=clamp01((t-4.13)/.47),amp=5*(1-q);camera=`translate(${f(Math.sin(t*73)*amp)},${f(Math.cos(t*81)*amp*.6)})`}
 }else if(t<13){
  shot=3;
  const rise=at(t,9.9,11.65),settle=at(t,11.75,12.5),press=B(t,9.3,9.8,10.3),release=at(t,9.8,10.75);
  let z={x:T(t,[[8,1230],[9.4,1223],[10,1210],[11.15,1250],[11.8,1270],[12.6,1270]]),y:T(t,[[8,650],[9.4,650],[9.8,662],[10.4,567],[11,430],[11.6,365],[11.9,373],[12.5,454]]),s:.70,angle:T(t,[[8,-3],[9.7,-6],[10.5,-3],[11.6,0],[12.5,0]]),chestX:T(t,[[8,-8],[9.5,-9],[9.9,-30],[10.6,19],[11.5,10],[12.1,30],[12.6,8]]),chestY:20-15*rise,shoulderTilt:5-2*rise,breath:Math.sin(t*2)*.7,headAngle:T(t,[[8,7],[9.2,11],[9.8,17],[10.7,1],[11.7,-4],[12.2,4],[12.8,1]]),yaw:T(t,[[8,-.4],[9.4,-.5],[10.2,-.22],[11.3,-.5],[12.7,-.3]]),pitch:.25-press*.4,smile:0,hurt:.8-rise*.3,concern:.35,gaze:-.7};
  const floor=[1112,1033],startW=local(z,floor),R=AR(startW,[35,375],release,80);
  z.R=arm(z,'R',R,{type:release>.65?'support':undefined,shadow:release<.05,k:1});z.L=arm(z,'L',[2,340],{E:[175,315],type:'loose'});
  let fin={x:T(t,[[8,875],[8.55,900],[9.5,905],[10.5,912],[11.6,910],[12.8,910]]),y:T(t,[[8,520],[8.6,545],[9.55,547],[9.85,560],[10.45,479],[11,391],[11.65,335],[12.1,341],[12.8,341]]),s:.72,angle:0,chestX:T(t,[[8,18],[8.7,40],[9.6,50],[10.1,63],[10.7,38],[11.6,8],[12.6,16]]),chestY:6+press*8,shoulderTilt:-6+rise*4,breath:Math.sin(t*1.7),headAngle:T(t,[[8,5],[9.1,9],[9.7,13],[10.4,3],[11.2,0],[11.9,3],[12.7,4]]),yaw:.4,pitch:.18-press*.12,smile:0,concern:.75,gaze:.8};
  const contact=pt(z,[-132,230]);fin.L=reaching(fin,'L',local(fin,contact),{bend:1,type:'grip',handAngle:-12});
  const thighHand=point(local(fin,[827,968]),[-125,480],rise);fin.R=arm(fin,'R',thighHand,{type:'loose',bend:1});
  const zh1=pt(z,[-57,480]),zh2=pt(z,[65,480]),fh1=pt(fin,[-57,480]),fh2=pt(fin,[65,480]);
  const zF1=point([1075,1037],[1145,1037],settle),zF2=point([1430,1037],[1395,1037],settle);
  zF1[1]-=20*Math.sin(Math.PI*settle);zF2[1]-=10*Math.sin(Math.PI*settle);
  const zK1=point(point([1110,1010],[1220,866],rise),[1145,856],settle),zK2=point(point([1360,1020],[1340,862],rise),[1400,856],settle);
  const fK1=point([800,990],[837,857],rise),fK2=point([1050,876],[1038,856],rise);
  s=bg('damaged')+chair(1282,799,.90)+`<ellipse cx="1610" cy="1045" rx="127" ry="9" fill="#233848" opacity=".18"/>`+prop('prop-chair-overturned',1610,1042,.58);
  s+=`<ellipse cx="1260" cy="1043" rx="205" ry="17" fill="#243849" opacity=".20"/><ellipse cx="945" cy="1043" rx="168" ry="14" fill="#243849" opacity=".18"/>`;
  s+=legs(z,zh1,zK1,zF1,zh2,zK2,zF2)+legs(fin,fh1,fK1,[850,1037],fh2,fK2,[1058,1037]);
  s+=figure('fin',fin,t)+figure('zei',z,t)+figure('zei',z,t,'hands')+figure('fin',fin,t,'hands')+dust(t,.6-rise*.25);
 }else{
  shot=t<19?4:5;const close=t>=19,calm=at(t,18.8,23.8),smile=at(t,22.4,23.65);
  let z={x:1165,y:380,s:.8,chestX:T(t,[[13,11],[14.2,3],[15.2,12],[16.1,5],[18.5,6],[20.1,10],[21.4,1],[22.4,7],[23.8,3]]),chestY:2*Math.sin(t*1.75),shoulderTilt:3,breath:Math.sin(t*1.75),headAngle:T(t,[[13,3],[13.6,-3],[14.6,0],[15.6,3],[16.5,0],[19,1],[20.25,-4],[21.1,0],[21.9,4],[22.7,-2],[23.6,0]]),yaw:T(t,[[13,-.25],[13.6,.55],[15,.45],[16.2,.25],[18.4,.35],[19.2,-.5],[20.6,-.55],[21.2,-.35],[21.8,.62],[22.45,-.3],[23.5,-.5]]),pitch:.04,smile:.35*smile,hurt:.4-calm*.2,concern:.2,gaze:T(t,[[13,0],[13.5,.8],[16,.3],[18.5,.5],[19,-.8],[21.3,-.5],[21.65,.9],[22.3,-.6],[23.8,-.7]])};
  guarded(z);
  z.headVelocity=1.5*B(t,13.1,13.5,14.1)-1.5*B(t,18.7,19.1,19.8)+2*B(t,21.3,21.8,22.1)-1.8*B(t,22.1,22.4,22.9);
  let fin={x:740,y:363,s:.8,chestX:T(t,[[13,7],[14.3,16],[15.5,10],[18,6],[19.4,14],[20.1,8],[21.8,13],[23.3,5]]),chestY:2*Math.sin(t*1.55+.8),shoulderTilt:-2,breath:Math.sin(t*1.55+.8),headAngle:T(t,[[13,5],[14,2],[15.8,6],[17.3,2],[19.2,6],[19.8,1],[21.1,4],[22.8,-2],[23.3,2],[23.8,0]]),yaw:.45,pitch:0,smile:.1+.35*smile,concern:.65-calm*.5,gaze:T(t,[[13,.75],[13.8,.95],[14.7,.7],[15.7,1],[19.7,.6],[22,.9],[23.8,.7]])};
  const healthyShoulder=pt(z,[-130,189]);fin.L=reaching(fin,'L',local(fin,healthyShoulder),{type:'grip',bend:1,handAngle:-8});
  fin.headVelocity=.6*B(t,19,19.35,19.9);
  fin.R=arm(fin,'R',[-120,454],{E:[-166,330],type:'loose'});
  const approach=at(t,13,13.65),deviceReach=at(t,13.8,14.7)*(1-at(t,17.8,18.75));
  const teach={x:mix(1665,1525,approach),y:406,s:.68,angle:0,chestX:-36*deviceReach,chestY:6*deviceReach,shoulderTilt:3,breath:Math.sin(t*1.7),headAngle:T(t,[[13,-5],[13.7,-9],[14.7,-6],[16.5,-4],[17.6,-9],[18.3,-4]]),yaw:-.58,pitch:.12,gaze:-.8,smile:.02,concern:.5};
  const device=AR([1514,702],[1328,650],deviceReach,48),grip=point(device,[device[0]+19,device[1]+21],1);
  teach.R=reaching(teach,'R',local(teach,grip),{type:'grip',bend:1,handAngle:-12});teach.L=arm(teach,'L',[118,450],{E:[170,330],type:'loose'});
  s=bg('damaged')+chair(755,795,.94)+chair(1180,799,.94)+`<ellipse cx="1745" cy="1049" rx="114" ry="8" fill="#233848" opacity=".18"/>`+prop('prop-chair-overturned',1745,1048,.52);
  s+=legs(fin,pt(fin,[-57,480]),[650,855],[660,1037],pt(fin,[65,480]),[875,855],[885,1037]);
  s+=legs(z,pt(z,[-57,480]),[1055,855],[1055,1037],pt(z,[65,480]),[1305,855],[1305,1037]);
  if(!close){const step=B(t,13,13.25,13.58);s+=legs(teach,pt(teach,[-57,480]),[teach.x-38,875],[teach.x-50,1038-step*24],pt(teach,[65,480]),[teach.x+78,878],[teach.x+106,1038])+figure('teacher',teach,t)}
  s+=figure('fin',fin,t)+figure('zei',z,t)+figure('zei',z,t,'hands')+figure('fin',fin,t,'hands');
  if(!close)s+=figure('teacher',teach,t,'hands')+prop('prop-scanner',device[0],device[1],.55,-10*deviceReach);
  if(t>14.25&&t<14.7){let alpha=Math.max(0,Math.sin((t-14.25)*Math.PI*8));s+=p('M1018,668q-12,-9 -6,-20M1027,666q-6,-8 -2,-15','none','#b2c9cc',2.8,`opacity="${f(alpha)}"`)}
  s+=dust(t,Math.max(.06,.45-at(t,18.8,22.5)*.39));
  if(close)camera='translate(-155,-85) scale(1.13)';
 }
 return{s,camera,shot};
}
function clamp01(v){return Math.max(0,Math.min(1,v))}
module.exports={build};
