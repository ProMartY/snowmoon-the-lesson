// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Original pose deformation helpers. Every control point is authored geometry.
const clamp=v=>Math.max(0,Math.min(1,v)),smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
const mix=(a,b,q)=>a+(b-a)*q;
function track(t,keys){
 if(t<=keys[0][0])return keys[0][1];if(t>=keys.at(-1)[0])return keys.at(-1)[1];
 let i=0;while(keys[i+1][0]<t)i++;
 const [a,x]=keys[i],[b,y]=keys[i+1],h=b-a,q=(t-a)/h;
 const slope=j=>{if(j<=0||j>=keys.length-1)return 0;const u=(keys[j][1]-keys[j-1][1])/(keys[j][0]-keys[j-1][0]),v=(keys[j+1][1]-keys[j][1])/(keys[j+1][0]-keys[j][0]);return u*v<=0?0:2*u*v/(u+v)};
 return (2*q*q*q-3*q*q+1)*x+(q*q*q-2*q*q+q)*h*slope(i)+(-2*q*q*q+3*q*q)*y+(q*q*q-q*q)*h*slope(i+1);
}
function pulse(t,a,b,c){return smooth((t-a)/(b-a))*(1-smooth((t-b)/(c-b)))}
function arc(A,B,q,lift=0){return[mix(A[0],B[0],q),mix(A[1],B[1],q)-Math.sin(q*Math.PI)*lift]}
function elbow(S,W,l1=168,l2=174,bend=1){
 const dx=W[0]-S[0],dy=W[1]-S[1],d=Math.max(.01,Math.hypot(dx,dy)),z=Math.min(d,l1+l2-.01),a=(l1*l1-l2*l2+z*z)/(2*z),b=Math.sqrt(Math.max(0,l1*l1-a*a))*bend;
 return[S[0]+dx/d*a-dy/d*b,S[1]+dy/d*a+dx/d*b];
}
// Handles the M/L/H/V/C/S/Q/T/Z path grammar used by the original coat artwork.
function warpPath(d,map){
 const tok=d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g)||[];let i=0,cmd='',x=0,y=0,sx=0,sy=0,last='',cp=null,out=[];
 const fmt=n=>Math.round(n*100)/100,pt=v=>map(v).map(fmt).join(','),num=()=>+tok[i++];
 while(i<tok.length){
  if(/[a-zA-Z]/.test(tok[i]))cmd=tok[i++];
  const c=cmd.toUpperCase(),rel=cmd!==c,ox=x,oy=y,read=()=>{let a=num(),b=num();return[rel?a+ox:a,rel?b+oy:b]};
  if(c==='Z'){out.push('Z');x=sx;y=sy;cp=null;last=c;cmd='';continue}
  if(c==='M'||c==='L'){const v=read();out.push(c+pt(v));[x,y]=v;if(c==='M'){sx=x;sy=y;cmd=rel?'l':'L'}cp=null}
  else if(c==='H'){x=num()+(rel?ox:0);out.push('L'+pt([x,y]));cp=null}
  else if(c==='V'){y=num()+(rel?oy:0);out.push('L'+pt([x,y]));cp=null}
  else if(c==='Q'){const a=read(),b=read();out.push('Q'+pt(a)+' '+pt(b));[x,y]=b;cp=a}
  else if(c==='T'){const a=(last==='Q'||last==='T')&&cp?[2*x-cp[0],2*y-cp[1]]:[x,y],b=read();out.push('Q'+pt(a)+' '+pt(b));[x,y]=b;cp=a}
  else if(c==='C'){const a=read(),b=read(),v=read();out.push('C'+pt(a)+' '+pt(b)+' '+pt(v));[x,y]=v;cp=b}
  else if(c==='S'){const a=(last==='C'||last==='S')&&cp?[2*x-cp[0],2*y-cp[1]]:[x,y],b=read(),v=read();out.push('C'+pt(a)+' '+pt(b)+' '+pt(v));[x,y]=v;cp=b}
  else throw Error('Unsupported authored path command '+c);
  last=c;
 }
 return out.join(' ');
}
function warpMarkup(svg,map){
 let s=svg.replace(/\bd="([^"]+)"/g,(_,d)=>'d="'+warpPath(d,map)+'"');
 s=s.replace(/<circle\b([^>]+)>/g,(all,a)=>{const x=a.match(/\bcx="([^"]+)"/),y=a.match(/\bcy="([^"]+)"/);if(!x||!y)return all;const v=map([+x[1],+y[1]]);return'<circle'+a.replace(/\bcx="[^"]+"/,'cx="'+v[0].toFixed(2)+'"').replace(/\bcy="[^"]+"/,'cy="'+v[1].toFixed(2)+'"')+'>'});
 return s;
}
function bodyPoint(P,[x,y]){
 const upper=smooth((492-y)/330),chest=smooth((y-130)/70)*(1-smooth((y-350)/145));
 return[x+(P.chestX||0)*upper+(P.hipX||0)*(1-upper)+x*(P.breath||0)*.012*chest,y+(P.chestY||0)*upper+(P.hipY||0)*(1-upper)+x*Math.sin((P.shoulderTilt||0)*Math.PI/180)*upper];
}
module.exports={track,pulse,arc,elbow,warpPath,warpMarkup,bodyPoint};
