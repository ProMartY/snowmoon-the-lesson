# Recorded sound effect sources

All sound recordings used in the released caption-and-effects cut are designated **CC0-1.0** by their original distributors. The source clips, mix and source hashes are in `../SOUND-MANIFEST.json`. No speech, TTS output, music, model weights or software executable is included here.

- **Kenney — Impact Sounds 1.0**: https://kenney.nl/assets/impact-sounds . CC0; original distribution notice retained as `kenney-impact-License.txt`.
- **Kenney — Interface Sounds 1.0**: https://kenney.nl/assets/interface-sounds . CC0; original distribution notice retained as `kenney-interface-License.txt`.
- **rubberduck — 100 CC0 SFX #2**: https://opengameart.org/content/100-cc0-sfx-2 . The original OpenGameArt entry identifies rubberduck as author and CC0 as license.
- **LEGIT Audio — The Shop free samples**: https://opengameart.org/content/the-shop . CC0 applies only to the free files supplied through OpenGameArt. No paid LEGIT Audio product is bundled.

Source license pages rechecked 19 October 2026. CC0 reference: https://creativecommons.org/publicdomain/zero/1.0/ . The original source recordings retain CC0 status; the package's GPL notice concerns the original adaptation art, code and production materials, and does not impose a new exclusive license on CC0 source recordings.

The fridge-appliance recording is used as quiet room/ventilation presence. It is not presented as an authentic classroom field recording. The effects are a sound-design adaptation, with offsets, trimming, filtering and levels documented in the manifest.
