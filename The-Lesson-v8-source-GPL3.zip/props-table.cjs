// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Original vector classroom table. Flat props share the tabletop homography.
// The table keeps the established world bounds: x104..1718, y811..1010.
const n=v=>Number(v.toFixed(3));
const p=(d,fill='none',stroke='#2f495f',w=2,extra='')=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${extra}/>`;
// Unit-square back-left, back-right, front-right, front-left map exactly to
// (218,811), (1558,811), (1718,915), (104,915). No bilinear approximation.
function tabletop(u,v){
 const h=1340/1614-1, den=1+h*v;
 return [(218+1340*u+(104*(1+h)-218)*v)/den,(811+(915*(1+h)-811)*v)/den];
}
const xy=(u,v)=>tabletop(u,v).map(n).join(',');
const edge=(a,b)=>p(`M${xy(...a)}L${xy(...b)}`,'none','#708697',1.1,'opacity=".52"');
const plane=(points,fill,stroke,w=1.6,extra='')=>p(points.map((q,i)=>(i?'L':'M')+xy(...q)).join('')+'Z',fill,stroke,w,extra);
function paperPoint(u,v){return [.267+u*.178,.15+v*.60];}
function paperLine(points,stroke='#84949c',w=1,extra=''){
 return p(points.map((q,i)=>(i?'L':'M')+xy(...paperPoint(...q))).join(''),'none',stroke,w,extra);
}
function desk(){
 let s='';
 // Rigid near edge, thin laminate lip, and a straight inset apron.
 s+=p('M104,915H1718L1715,934H107Z','#8093a2','#2f495f',3.2);
 s+=p('M116,934H1710V1010H116Z','#5d7385','#2f495f',3.6);
 s+=p('M104,915L218,811V827L107,934Z','#617d91','#304c63',2.6);
 s+=p('M1558,811L1718,915L1715,934L1558,827Z','#6a8396','#304c63',2.6);
 s+=p('M218,811H1558L1718,915H104Z','#b5c0c6','#2f495f',3.4);
 // Exact projective border inset keeps every edge on one planar surface.
 s+=plane([[.008,.055],[.992,.055],[.987,.94],[.013,.94]],'none','#dfe5e6',1,'opacity=".55"');
 s+=p('M108,923H1713M121,941H1705M121,1004H1705','none','#a4b5c0',1.3,'opacity=".67"');
 // The inset front face is rectangular and uses straight manufacturable panels.
 s+=p('M136,949H1691V995H136Z','none','#3f5c73',1.5,'opacity=".72"');
 s+=p('M386,949V995M1400,949V995','none','#3f5c73',1.5,'opacity=".72"');
 s+=p('M141,952H1685','none','#a3b3bd',.9,'opacity=".45"');
 // Subtle original wear: sparse marks, projected with the surface instead of
 // arbitrary world-space curves. The silhouette and corners remain ruler-straight.
 const marks=[[.08,.25,.016],[.13,.72,.028],[.21,.41,.022],[.33,.09,.03],[.47,.27,.02],[.57,.83,.027],[.66,.33,.018],[.72,.65,.03],[.86,.15,.024],[.92,.8,.019]];
 for(const[u,v,l]of marks)s+=edge([u,v],[u+l,v]);
 // One paper sheet has a correct planar contact shadow and a small thickness.
 const corners=[[0,0],[1,0],[1,1],[0,1]].map(q=>paperPoint(...q));
 const shadow=corners.map(q=>[q[0]+.0015,q[1]+.027]);
 s+=plane(shadow,'#627d8b','none',0,'opacity=".20"');
 s+=plane(corners,'#e2e6e2','#70838f',1.4);
 s+=paperLine([[.07,.1],[.93,.1]],'#c7d1d1',.8);
 // Original diagram, no illegible pseudo-words: two gas jars and a direction arrow.
 s+=paperLine([[.08,.25],[.48,.25]],'#8a9da5',1.15);
 s+=paperLine([[.08,.33],[.38,.33]],'#9aabb0',.9);
 s+=paperLine([[.1,.52],[.1,.86],[.31,.86],[.31,.52],[.1,.52]],'#718d9e',1.15);
 s+=paperLine([[.64,.52],[.64,.86],[.86,.86],[.86,.52],[.64,.52]],'#718d9e',1.15);
 s+=paperLine([[.4,.69],[.55,.69],[.51,.62]],'#718d9e',1.1);
 s+=paperLine([[.55,.69],[.51,.76]],'#718d9e',1.1);
 for(const[u,v]of[[.15,.61],[.24,.73],[.16,.8],[.69,.6],[.77,.62],[.83,.72],[.73,.79],[.67,.72]]){
  const P=paperPoint(u,v),[x,y]=tabletop(...P);s+=`<ellipse cx="${n(x)}" cy="${n(y)}" rx="1.8" ry=".7" fill="#658a9e"/>`;
 }
 // A straight pen is projected from one plane with a single centre line.
 const A=[.49,.64],B=[.558,.39],dx=B[0]-A[0],dy=B[1]-A[1],length=Math.hypot(dx,dy),nx=-dy/length*.0012,ny=dx/length*.0012;
 const pen=[[A[0]+nx,A[1]+ny],[B[0]+nx,B[1]+ny],[B[0]-nx,B[1]-ny],[A[0]-nx,A[1]-ny]];
 s+=plane(pen.map(q=>[q[0]+.001,q[1]+.021]),'#526f7e','none',0,'opacity=".23"');
 s+=plane(pen,'#36546b','#263e54',1);
 const P=(q,t)=>[q[0]+dx*t,q[1]+dy*t];
 const tip=P(A,1.045);
 s+=plane([[B[0]+nx,B[1]+ny],tip,[B[0]-nx,B[1]-ny]],'#cad6da','#526f84',.8);
 const c1=P(A,.12),c2=P(A,.39);
 s+=p(`M${xy(c1[0]+nx*.35,c1[1]+ny*.35)}L${xy(c2[0]+nx*.35,c2[1]+ny*.35)}`,'none','#d0dce0',.8);
 return s;
}
module.exports={desk,tabletop};
