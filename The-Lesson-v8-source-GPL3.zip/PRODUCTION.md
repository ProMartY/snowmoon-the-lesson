# Production record and reusable brief

The approved public version uses English captions and recorded CC0 effects, with no spoken voices. The generated-voice candidate described below was a historical timing reference and is excluded from the release.

## Creative brief

Adapt the Chapter 2 physics lesson interruption: a distant structural thump; a small right-side breach to an adjacent underground room; a stone striking Zei's left arm; Fin helping him from the floor to a chair; the instructor checking the arm; ventilation, a quiet offer of help, and shared relief. Keep violence off-screen and injury non-graphic. Use fictional European-appearance characters, a cold silver/blue-grey/sage palette, clear silhouettes, drawn textures and English dialogue.

## Actual picture workflow

The delivered picture is the v8 original-vector revision. Contours, background, furniture, clothing marks and simplified science murals were authored as SVG paths and JavaScript path strings with Codex assistance. They are not imported stock models or neural-generated images. Earlier generated visual studies and rejected procedural 3D trials were not used as picture assets in this cut and are not part of this package.

The v8 revision replaces rigid whole-figure motion with staged head/shoulder changes, asymmetric reaction, a planted crouch, a controlled lift and seat contact, and secondary cloth/hair settling. Face turns project authored contours; they are a stylized approximation, not anatomically complete 3D rotations. Furniture uses native proportions and uniform scaling. Paper and pen use one tabletop homography.

Shot windows: 0–4 seconds quiet lesson;4–8 seconds incident/reaction;8–13 seconds assistance;13–19 seconds check;19–24 seconds relief. The small cast and continuous floor plane intentionally compress the prose scene.

Sharp/librsvg rasterizes each 1920×1080 SVG at its own authored timestamp. FFmpeg encodes 2880 picture frames at 120 fps. The frame rate is a sampling/delivery rate, not a claim of 2880 individually hand-drawn key poses. No neural video service, image-to-video output, optical-flow interpolation, paid video subscription or upscaling is used in this picture pipeline.

## Dialogue reference and mouth timing

The private reference used short generated neural voices via Microsoft Edge online TTS and edge-tts 7.3.1: RyanNeural for the instructor, ThomasNeural for Fin, and BrianMultilingualNeural for Zei. It does not clone a named real person or use recordings by hired actors. Those outputs are not included in this source package, and no redistribution right is asserted here.

The final cue text, voice identifiers, rates, trimming, gain, actual service word boundaries and absolute timeline positions are described in DIALOGUE.json. Mouth envelopes measure activity from that reference. Additional mouth labels use word-boundary timing and spelling/pronunciation heuristics, not forced phoneme alignment. Native pitch was retained and the takes were not post-time-stretched. A short first take was replaced to fit the opening window.

The original sound design recipe used licensed CC0 source clips for quiet room presence, a structural thump, stone/debris, chair/cloth contact and a watch cue. No music or trailer-style impact score is used. The actual used CC0 source clips, mix and source/license manifest are included under `audio/`. External tool binaries are not bundled. `assemble-captions.cjs` produces the approved caption/effects format; optional future soundtracks can use `assemble-audio.cjs` only with separately established rights.

## AI disclosure and limits

OpenAI Codex agents assisted story compression, dialogue adaptation, original SVG/code drawing, acting curves, mouth heuristics, corrections, rendering, representative visual inspection and packaging. The publisher selected the scene and approved the original vector direction. This production is code-assisted and includes generated-voice references; it must not be marketed as a traditionally hand-drawn film or a human-acted recording.

The package does not assert perfect anatomy, human listening review, endorsement, contest acceptance or earnings. Read the code and source art to inspect or improve the process.
