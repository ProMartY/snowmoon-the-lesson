// SPDX-License-Identifier: GPL-3.0-only
// The Lesson; Snowmoon Chapter 2 by Vitalik Buterin.
// Adaptation production: ProMartY, with OpenAI Codex assistance.
// Original vector facial posing. No raster or image/video model assets.
// Head-local origin matches draw-core.face/hair; caller positions/rolls neck.
const C=require('./draw-core.cjs');
const {p,f,skin,skinShade,skinLight,ink}=C;
const limit=(n,lo=0,hi=1)=>Math.max(lo,Math.min(hi,Number.isFinite(+n)?+n:0));
const lerp=(a,b,q)=>a+(b-a)*q;

// Convert all used SVG curve commands to absolute coordinates before projection.
// Relative hair curls must not be projected as if they were global coordinates.
function projectPath(d,point){
 const tokens=d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g)||[];
 const count={M:2,L:2,Q:4,C:6,T:2,H:1,V:1,S:4};
 let out='',i=0,cmd='',x=0,y=0,sx=0,sy=0;
 while(i<tokens.length){
  if(/[a-zA-Z]/.test(tokens[i]))cmd=tokens[i++];
  const op=cmd.toUpperCase(),rel=cmd!==op;
  if(op==='Z'){out+='Z ';x=sx;y=sy;cmd='';continue}
  const n=count[op];if(!n)throw Error('Unsupported authored SVG command '+cmd);
  if(i+n>tokens.length)throw Error('Incomplete authored SVG command '+cmd);
  const v=tokens.slice(i,i+n).map(Number);i+=n;
  if(op==='H'){x=rel?x+v[0]:v[0];out+=`L${point(x,y)} `;continue}
  if(op==='V'){y=rel?y+v[0]:v[0];out+=`L${point(x,y)} `;continue}
  const pts=[];for(let k=0;k<n;k+=2)pts.push([v[k]+(rel?x:0),v[k+1]+(rel?y:0)]);
  out+=op+pts.map(P=>point(...P).join(',')).join(' ')+' ';
  [x,y]=pts[pts.length-1];
  if(op==='M'){sx=x;sy=y;cmd=rel?'l':'L'}
 }
 return out;
}

function blinkAt(t,kind){
 // Deliberate blinks: distinct timings per actor, not a looping lid oscillation.
 const starts=kind==='fin'?[.21,2.92,7.82,11.44,15.12,19.88,23.12]:kind==='teacher'?[1.12,13.18,16.71,20.08]:[.72,3.55,8.12,13.33,18.61,22.68];
 let v=0;for(const start of starts){const q=(t-start)/.15;if(q>=0&&q<=1)v=Math.max(v,Math.sin(Math.PI*q))}return v;
}

function head(kind,t=0,opts={}){
 const fin=kind==='fin',teacher=kind==='teacher';
 const yaw=limit(opts.yaw===undefined?(opts.gaze||0)*.13:opts.yaw,-1,1),pitch=limit(opts.pitch||0,-1,1);
 const gaze=limit(opts.gaze||0,-1,1),smile=limit(opts.smile||0,-1,1);
 const hurt=limit(opts.hurt||0),alarm=limit(opts.alarm||0),concern=limit(opts.concern||0);
 const talk=limit(opts.talk||0),viseme=opts.viseme||'neutral';
 const blink=limit(opts.blink===undefined?blinkAt(t,kind):opts.blink);
 const velocity=limit(opts.headvelocity||0,-2,2);
 const ang=yaw*.92,co=Math.cos(ang),si=Math.sin(ang),pa=pitch*.18;
 const isSpeaking=talk>.035&&viseme!=='closed';
 const jawOpen=isSpeaking?(viseme==='round'?6+talk*8:viseme==='wide'?talk*9:talk*17):0;
 const depth=(x,y)=>24*Math.sqrt(Math.max(0,1-(x/125)**2))*(.75+.25*Math.cos(y/180));
 const P=(x,y,z)=>{
  z=z===undefined?depth(x,y):z;
  return [f(x*co+z*si),f(y*Math.cos(pa)-z*Math.sin(pa)+jawOpen*limit((y-40)/105))];
 };
 const HP=(x,y)=>{
  const z=19+20*Math.sqrt(Math.max(0,1-(x/140)**2));
  const lag=-velocity*1.75*limit((-y+15)/185);
  return [f(x*co+z*si+lag),f(y*Math.cos(pa)-z*Math.sin(pa)-velocity*.23*limit(-y/150))];
 };
 const draw=(d,fill='none',stroke=ink,w=3,extra='')=>p(projectPath(d,P),fill,stroke,w,extra);
 const hairDraw=(d,fill,stroke=ink,w=3,extra='')=>p(projectPath(d,HP),fill,stroke,w,extra);
 let s='';
 // The near and far ears change size/visibility rather than sliding together.
 for(const side of[-1,1]){
  const far=side===Math.sign(yaw),show=far?1-Math.abs(yaw)*.86:1;
  if(show<.12)continue;
  const ex=side*101,ey=-16,ew=(11+Math.abs(yaw)*(far?-5:2))*show;
  const ep=P(ex,ey,far?-9:7);
  s+=`<g opacity="${f(show)}">`+p(`M${ep[0]},${ep[1]-24} C${f(ep[0]+side*ew*1.7)},${ep[1]-38} ${f(ep[0]+side*ew*1.9)},${ep[1]+15} ${ep[0]},${ep[1]+31} L${f(ep[0]-side*5)},${ep[1]+13}Z`,skin,ink,2.8);
  s+=p(`M${f(ep[0]+side*3)},${ep[1]-13} Q${f(ep[0]+side*ew)},${ep[1]-22} ${f(ep[0]+side*ew*.7)},${ep[1]+5} Q${f(ep[0]+side*3)},${ep[1]+10} ${f(ep[0]+side*2)},${ep[1]+2}`,'none','#9d939f',1.8)+'</g>';
 }
 // Jaw/cheek contours deform in the turn and with actual speech opening.
 s+=draw('M-94,-73 C-93,-129 -43,-148 19,-141 C78,-138 106,-96 99,-42 L95,37 Q89,99 39,127 Q7,146 -26,130 Q-62,116 -85,71 L-99,12 Q-106,-30 -94,-73Z',skin,ink,3.6);
 s+=draw('M-89,-58 Q-62,-114 -16,-122 Q42,-128 83,-83 Q82,-47 91,-12 L84,56 Q63,105 29,124 Q-21,133 -54,103 Q-18,126 12,106 Q57,80 67,31 L65,-55 Q19,-91 -31,-74Z',skinShade,'none',0,'opacity=".25"');
 s+=draw('M-66,41 Q-49,34 -28,43 Q-39,64 -59,58Z','#c9aeb8','none',0,'opacity=".22"');
 s+=draw('M43,37 Q62,26 79,37 L70,55 Q56,59 47,48Z','#c9aeb8','none',0,'opacity=".20"');
 if(teacher){
  // Short beard follows sideburns, cheeks and jaw. An actual opening around
  // the lips exposes skin; a solid band across this area read like a mask.
  s+=draw('M-87,34 Q-78,42 -65,61 Q-53,71 -42,71 Q-16,58 9,64 Q34,58 57,65 Q74,52 88,34 L86,78 Q70,111 39,132 Q7,148 -28,133 Q-64,117 -82,86Z M-42,66 Q-17,55 8,61 Q38,56 58,68 Q55,91 34,100 Q6,109 -17,99 Q-38,92 -42,66Z','#6c665e',ink,2.25,'fill-rule="evenodd"');
  s+=draw('M-77,77 Q-58,103 -30,117 Q3,133 36,121 Q66,108 80,79 L76,92 Q52,129 13,137 Q-28,139 -59,110Z','#535955','none',0,'opacity=".32"');
  for(let i=0;i<16;i++){const x=-62+i*9;const y=106+Math.sin(i*.42)*12;s+=draw(`M${x},${y}l1,7`,'none','#9b9992',1,'opacity=".5"')}
 }
 // Eyelid geometry, eye spacing, pupils and brow ends all turn independently.
 for(const side of[-1,1]){
  const far=side===Math.sign(yaw),squish=1-Math.abs(yaw)*(far?.58:.09);
  const cx=side*43,cy=(fin?(side<0?-10:-14):(side<0?-12:-10))-pitch*4;
  const center=P(cx,cy,31),width=(side<0?27:25)*squish;
  const asym=side<0?hurt*.12:0;
  const eyeOpen=limit((1-blink)*(1+alarm*.38-hurt*.46-concern*.08-asym),.015,1.4);
  const eh=10*eyeOpen;
  const edgeSlope=yaw*side*1.2+hurt*side*2;
  const x0=center[0]-width,x1=center[0]+width,y0=center[1]-edgeSlope,y1=center[1]+edgeSlope;
  const ed=`M${f(x0)},${f(y0)} Q${center[0]},${f(center[1]-eh)} ${f(x1)},${f(y1)} Q${center[0]},${f(center[1]+eh*.88)} ${f(x0)},${f(y0)}Z`;
  const id=`eye-${kind}-${String(opts.id||`${t}-${yaw}`).replace(/[^a-zA-Z0-9_-]/g,'')}-${side<0?'l':'r'}`;
  if(eyeOpen>.12){
   s+=`<defs><clipPath id="${id}">${p(ed,'white','none',0)}</clipPath></defs>`+p(ed,'#ecece3',ink,1.65);
   const gx=gaze*8.5+si*1.5,px=center[0]+gx,py=center[1]+.5+pitch*2;
   s+=`<g clip-path="url(#${id})"><ellipse cx="${f(px)}" cy="${f(py)}" rx="${f(7.6*squish)}" ry="9.1" fill="${fin?'#6d777b':teacher?'#777b78':'#63767a'}"/><ellipse cx="${f(px)}" cy="${f(py)}" rx="${f(3.3*squish)}" ry="5.5" fill="#263745"/><circle cx="${f(px-2)}" cy="${f(py-2.5)}" r="1.5" fill="#edf4ee"/></g>`;
  }
  s+=p(`M${f(x0)},${f(y0)} Q${center[0]},${f(center[1]-eh)} ${f(x1)},${f(y1)}`,'none',ink,3.1);
  if(eyeOpen>.18)s+=p(`M${f(x0+3)},${f(center[1]+17)} Q${center[0]},${f(center[1]+21)} ${f(x1-3)},${f(center[1]+16)}`,'none','#b2a4ae',teacher?1.8:1.2,'opacity=".62"');
  const inner=side<0?x1-1:x0+1,outer=side<0?x0+2:x1-2;
  const iy=center[1]-27-concern*9-hurt*12-alarm*6+(side<0?-smile*2:smile*1.5);
  const oy=center[1]-28+hurt*4-alarm*13+(side<0?-concern*1:concern*3);
  s+=p(`M${f(outer)},${f(oy)} Q${center[0]},${f(Math.min(oy,iy)-8)} ${f(inner)},${f(iy)}`,'none',fin?'#61544e':teacher?'#6b6057':'#323a41',teacher?6.8:5.7);
 }
 // Nose bridge and tip project in front of the cheeks, changing the silhouette.
 const n0=P(7,-8,35),n1=P(10,10,48),nt=P(22,25,61),nb=P(-1,27,38);
 s+=p(`M${n0} Q${n1} ${nt} Q${P(9,33,47)} ${nb}`,'none','#a79ca8',2.4);
 s+=p(`M${P(8,6,42)} L${P(19,23,56)} L${P(6,26,45)}Z`,'#d3bfc2','none',0);
 // Phoneme poses change the lips and jaw, not just opacity of a smiling hole.
 const my=76-smile*2+hurt*2,mc=P(7,my,37);
 const mw=(viseme==='round'?12:viseme==='wide'?32:25)*(1-Math.abs(yaw)*.24);
 const open=isSpeaking?(viseme==='round'?8+talk*10:viseme==='wide'?3+talk*7:3+talk*20):0;
 const cornerL=mc[1]+hurt*2-smile*3,cornerR=mc[1]+hurt*4-smile*5;
 if(open>.7){
  s+=p(`M${f(mc[0]-mw)},${f(cornerL)} Q${mc[0]},${f(mc[1]-4+(viseme==='round'?-3:0))} ${f(mc[0]+mw)},${f(cornerR)} Q${f(mc[0]+mw*.9)},${f(mc[1]+open)} ${mc[0]},${f(mc[1]+open+2)} Q${f(mc[0]-mw*.85)},${f(mc[1]+open)} ${f(mc[0]-mw)},${f(cornerL)}Z`,'#61535f','#7f6974',2.1);
  if(viseme==='wide'||(viseme==='open'&&talk>.5&&hurt<.2))s+=p(`M${f(mc[0]-mw+4)},${f(cornerL+1)} Q${mc[0]},${f(mc[1]-1)} ${f(mc[0]+mw-4)},${f(cornerR+1)} L${f(mc[0]+mw-6)},${f(mc[1]+5)} Q${mc[0]},${f(mc[1]+7)} ${f(mc[0]-mw+6)},${f(mc[1]+5)}Z`,'#e7e4d9','none',0);
  if(open>12)s+=p(`M${f(mc[0]-mw*.45)},${f(mc[1]+open-2)} Q${mc[0]},${f(mc[1]+open-6)} ${f(mc[0]+mw*.45)},${f(mc[1]+open-2)}`,'none','#a87c87',3);
 }else s+=p(`M${f(mc[0]-29)},${f(cornerL)} Q${f(mc[0]+2)},${f(mc[1]+8-smile*10-hurt*9)} ${f(mc[0]+32)},${f(cornerR)}`,'none','#7f6974',viseme==='closed'?3.25:2.6);
 s+=p(`M${f(mc[0]-13)},${f(mc[1]+open+16)} Q${f(mc[0]+1)},${f(mc[1]+open+20)} ${f(mc[0]+17)},${f(mc[1]+open+15)}`,'none',teacher?'#a4a19a':'#b7a4ae',1.5,'opacity=".75"');
 if(smile>.15)s+=p(`M${f(mc[0]+34)},${f(cornerR-2)}q5,0 6,5`,'none','#b09aab',1.2);
 if(fin)for(const[x,y,r]of[[-64,24,1.7],[-55,29,1.3],[-44,25,1.6],[-35,32,1.3],[48,24,1.5],[59,26,1.3],[67,22,1.6]]){const pt=P(x,y,26);s+=`<circle cx="${pt[0]}" cy="${pt[1]}" r="${r}" fill="#a39195" opacity=".63"/>`}
 if(teacher){
  s+=draw('M-101,-10 Q-115,-43 -108,-80 Q-112,-118 -81,-135 Q-47,-161 -2,-155 Q40,-163 83,-135 Q114,-114 105,-76 L95,-18 L82,-12 L80,-67 Q57,-98 31,-106 Q-6,-80 -43,-86 Q-72,-76 -85,-45 L-88,-12Z','#726659',ink,3.9);
  for(const d of['M-92,-103q38,-38 82,-34','M-55,-120q38,-21 72,-19','M-5,-130q44,-6 73,20','M57,-124q27,13 33,30'])s+=hairDraw(d,'none','#a69b8a',2.2);
  // A split moustache leaves the philtrum/lip free for round/open phonemes.
  s+=draw('M-34,68 Q-19,57 -3,61 Q3,64 8,65 L0,70 Q-9,67 -23,72 L-34,75Z M11,65 Q26,57 43,61 L56,67 L53,74 Q32,66 18,71Z','#655e56',ink,1.15);
 }else{
  // Keep approved curl/tousled silhouettes; project every absolute control
  // point so turns alter volume/overlaps rather than rigidly translate a card.
  const raw=C.hair(kind,0).replace(/<g[^>]*>/g,'').replace(/<\/g>/g,'');
  s+=raw.replace(/d="([^"]+)"/g,(_,d)=>`d="${projectPath(d,HP)}"`);
 }
 return `<g data-original-head="${kind}" data-yaw="${f(yaw)}" data-viseme="${viseme}">${s}</g>`;
}

module.exports={head,projectPath,blinkAt};

if(require.main===module){
 const fs=require('node:fs'),path=require('node:path');
 const sharp=require('sharp');
 const poses=[
  ['left turn',{yaw:-.8,pitch:-.15,gaze:-.65,smile:.12}],
  ['neutral',{yaw:0,smile:.15,gaze:.1}],
  ['right turn',{yaw:.8,pitch:.2,gaze:.65,smile:.12,headvelocity:.7}],
  ['concern',{yaw:.3,pitch:.35,concern:.8,hurt:.15,smile:0}],
  ['hurt / closed',{yaw:-.25,hurt:.9,viseme:'closed',talk:.4}],
  ['round vowel',{yaw:-.45,viseme:'round',talk:.85,concern:.2}],
  ['wide vowel',{yaw:.25,viseme:'wide',talk:.8}],
  ['open / alarm',{yaw:.45,alarm:.8,viseme:'open',talk:.7}],
  ['blink',{yaw:-.4,blink:.98,smile:.1}]
 ];
 let svg='<svg xmlns="http://www.w3.org/2000/svg" width="2160" height="1500" viewBox="0 0 2160 1500"><rect width="2160" height="1500" fill="#233747"/>';
 for(const [row,kind]of['fin','zei','teacher'].entries())for(let col=0;col<poses.length;col++){
  const [label,opts]=poses[col],w=240,x=col*w+w/2,y=row*500+255;
  svg+=`<g transform="translate(${x},${y}) scale(.91)">`+head(kind,0,{...opts,id:`qa-${row}-${col}`})+'</g>';
  svg+=`<text x="${x}" y="${row*500+425}" fill="#d8e4e9" font-family="Segoe UI, sans-serif" text-anchor="middle" font-size="17">${kind} / ${label}</text>`;
 }
 svg+='</svg>';fs.mkdirSync(path.join(__dirname,'qa'),{recursive:true});
 fs.writeFileSync(path.join(__dirname,'qa/faces-acting-contact.svg'),svg);
 sharp(Buffer.from(svg)).png().toFile(path.join(__dirname,'qa/faces-acting-contact.png')).then(()=>console.log(path.join(__dirname,'qa/faces-acting-contact.png'))).catch(e=>{console.error(e);process.exitCode=1});
}
