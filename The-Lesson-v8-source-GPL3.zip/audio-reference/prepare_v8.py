# SPDX-License-Identifier: GPL-3.0-only
# Historical v8 audio pipeline reference; output rights were not established.
# ProMartY with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
import os, sys
if "--enable-reference-processing" not in sys.argv:
    raise SystemExit("Reference-only harness. No service or processing invoked. Read audio-reference/README.md before opting in with --enable-reference-processing.")
"""Prepare native-pitch v8 takes and approximate word-timed mouth shapes.

No pitch shifting or time stretching. Mouth labels are phoneme-spelling heuristics
inside actual service word boundaries, not forced-aligned phonemes or visemes.
"""
from pathlib import Path
import hashlib,json,math,subprocess,wave
import numpy as np

HERE=Path(__file__).resolve().parent
FILM=HERE.parent
REFERENCE_INPUT=HERE/'licensed-input'
FFMPEG=os.environ.get('FFMPEG','ffmpeg')
SR=48000;FPS=120

def read(path):
    with wave.open(str(path),'rb') as src:
        assert src.getframerate()==SR and src.getnchannels()==1
        return np.frombuffer(src.readframes(src.getnframes()),'<i2').astype(float)/32768

def write(path,x):
    assert float(np.max(abs(x)))<.999
    with wave.open(str(path),'wb') as out:
        out.setnchannels(1);out.setsampwidth(2);out.setframerate(SR)
        out.writeframes((x*32767).astype('<i2').tobytes())

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def edges(x):
    rms=np.array([np.sqrt(np.mean(x[i:i+480]**2)) for i in range(0,len(x),480)])
    active=np.where(rms>.00075)[0]
    if not len(active):raise RuntimeError('Silent take')
    return max(0,int(active[0]*480-SR*.035)),min(len(x),int((active[-1]+1)*480+SR*.07))

def activity(x):
    vals=[]
    for frame in range(math.ceil(len(x)/SR*FPS)):
        a=max(0,int((frame/FPS-.008)*SR));b=min(len(x),int((frame/FPS+.016)*SR))
        vals.append(float(np.sqrt(np.mean(x[a:b]**2))) if b>a else 0.)
    ar=np.array(vals);top=max(.005,float(np.percentile(ar,90)))
    ar=np.sqrt(np.clip((ar-.001)/(top-.001),0,1))
    return [round(float(v),3) if v>.075 else 0. for v in ar]

# Ordered coarse shapes, inferred from ordinary English pronunciation.
# Fractions partition each actual WordBoundary. These are not model phonemes.
PATTERNS={
    'well':[('neutral',.2),('wide',.6),('neutral',.2)],
    'zay':[('neutral',.16),('wide',.84)],
    "you've":[('round',.7),('neutral',.3)],
    'got':[('neutral',.18),('wide',.64),('neutral',.18)],
    'it':[('neutral',1)],
    'right':[('neutral',.15),('wide',.68),('neutral',.17)],
    'easy':[('wide',.72),('neutral',.28)],
    "i've":[('wide',.75),('neutral',.25)],
    'you':[('round',1)],
    'my':[('closed',.2),('wide',.8)],
    'arm':[('wide',.75),('closed',.25)],
    'does':[('neutral',.2),('wide',.55),('neutral',.25)],
    'hurt':[('neutral',1)],
    'a':[('wide',1)],
    'bit':[('closed',.2),('neutral',.8)],
    'little':[('neutral',.2),('wide',.4),('neutral',.4)],
    "i'll":[('wide',.75),('neutral',.25)],
    'be':[('closed',.22),('wide',.78)],
    'okay':[('round',.45),('wide',.55)],
    'get':[('neutral',.15),('wide',.65),('neutral',.2)],
    'checked':[('neutral',.25),('wide',.5),('neutral',.25)],
    'today':[('neutral',.2),('round',.2),('wide',.6)],
    'take':[('neutral',.15),('wide',.7),('neutral',.15)],
    'i':[('wide',1)],
    'know':[('neutral',.22),('round',.78)],
    'less':[('neutral',.1),('wide',.7),('neutral',.2)],
    'about':[('wide',.25),('closed',.15),('round',.45),('neutral',.15)],
    'that':[('neutral',.15),('wide',.7),('neutral',.15)],
    'wall':[('neutral',.12),('round',.72),('neutral',.16)],
    'now':[('neutral',.18),('wide',.4),('round',.42)],
}

def srt_time(t):
    ms=round(t*1000);h=ms//3600000;ms%=3600000;m=ms//60000;ms%=60000;s=ms//1000
    return f'{h:02}:{m:02}:{s:02},{ms%1000:03}'

def main():
    d=json.loads((FILM/'DIALOGUE.json').read_text(encoding='utf-8'))
    wavdir=HERE/'wav';wavdir.mkdir(exist_ok=True)
    cuedir=HERE/'cues';cuedir.mkdir(exist_ok=True)
    mix=np.zeros(24*SR);envelopes={};events=[];qa=[]
    for c in d['cues']:
        cid=c['id'];src=HERE/'raw'/(cid+'.mp3');wavpath=wavdir/(cid+'.wav')
        subprocess.run([str(FFMPEG),'-y','-hide_banner','-loglevel','error','-i',str(src),'-ac','1','-ar',str(SR),str(wavpath)],check=True)
        raw=read(wavpath);a,b=edges(raw);x=raw[a:b]
        # Level each actor around conversational speech RMS, preserving dynamics.
        target_db=-22.5 if c['character']=='teacher' else -23.5
        if cid=='03-zei-arm':target_db=-24.5
        speech=x[abs(x)>.002]
        speech_rms=float(np.sqrt(np.mean(speech**2)))
        gain=min(10**(target_db/20)/max(.0001,speech_rms),.40/max(abs(x)))
        x=x*gain
        fade=min(240,len(x)//8);x[:fade]*=np.linspace(0,1,fade);x[-fade:]*=np.linspace(1,0,fade)
        duration=len(x)/SR
        if c['start']+duration>c['target_end']+.04:
            raise RuntimeError(f"{cid} needs recasting or shorter text, not time stretch: {duration:.3f}s")
        out=cuedir/(cid+'.wav');write(out,x)
        p=round(c['start']*SR);mix[p:p+len(x)]+=x
        c.update({'audio_file':str(out.resolve()),'duration':round(duration,6),'end':round(c['start']+duration,6),'raw_duration':len(raw)/SR,'trim_raw_start':a/SR,'trim_raw_end':b/SR,'post_tempo':1.,'post_pitch_shift':0.,'gain_db':round(20*math.log10(gain),3),'sample_rate':SR,'mouth_envelope_id':cid})
        env=activity(x);envelopes[cid]={'character':c['character'],'start':c['start'],'fps':FPS,'values':env}
        words=[]
        for w in json.loads(src.with_suffix('.words.json').read_text(encoding='utf-8')):
            ws=max(0,w['offset']/1e7-a/SR);we=min(duration,(w['offset']+w['duration'])/1e7-a/SR)
            if we<=ws:continue
            word=w['text'];words.append({'text':'Zei' if word=='Zay' else word,'start':round(c['start']+ws,6),'end':round(c['start']+we,6)})
            phases=PATTERNS.get(word.lower().strip('.,?!—'),[('neutral',1)])
            cursor=ws
            for shape,fraction in phases:
                end=cursor+(we-ws)*fraction
                events.append({'character':c['character'],'cue_id':cid,'start':round(c['start']+cursor,6),'end':round(c['start']+end,6),'shape':shape,'word':'Zei' if word=='Zay' else word,'method':'actual word boundary + approximate phoneme-spelling heuristic'})
                cursor=end
        c['approximate_words']=words
        qa.append({'id':cid,'start':c['start'],'end':c['end'],'duration':duration,'native_pitch':True,'post_time_stretch':False,'peak_dbfs':20*math.log10(max(abs(x))),'clipped_samples':int(np.sum(abs(x)>=.999))})
    voicepath=HERE/'The-Lesson-English-dialogue-24s.wav';write(voicepath,mix)
    foley_src=REFERENCE_INPUT/'audio/The-Lesson-CC0-foley-24s.wav';foley=read(foley_src)
    assert len(foley)==len(mix)
    foley_path=HERE/'The-Lesson-CC0-foley-24s.wav';foley_path.write_bytes(foley_src.read_bytes())
    combined=mix+foley
    final=HERE/'The-Lesson-English-final-mix-24s.wav';write(final,combined)
    for path in [voicepath,final]:
        subprocess.run([str(FFMPEG),'-y','-hide_banner','-loglevel','error','-i',str(path),'-c:a','libmp3lame','-b:a','192k',str(path.with_suffix('.mp3'))],check=True)
    (HERE/'mouth-envelopes-120fps.json').write_text(json.dumps({'fps':FPS,'type':'actual speech amplitude activity, separate from approximate viseme labels','cues':envelopes},indent=2),encoding='utf-8')
    viseme={'fps':FPS,'duration':24,'method':'Actual TTS word boundaries plus approximate spelling/phoneme heuristics. NOT forced-aligned phonemes or model visemes. Use amplitude activity to close the mouth during internal pauses.','default_shape':'closed','shapes':{'closed':'M/B/P lip closure and silence','round':'O/U rounded vowels','wide':'A/E and open vowels','neutral':'other consonants / small neutral opening'},'events':sorted(events,key=lambda e:e['start']),'frames':{}}
    for who in ['teacher','fin','zei']:
        labels=[]
        for frame in range(24*FPS):
            t=frame/FPS;active=next((e for e in viseme['events'] if e['character']==who and e['start']<=t<e['end']),None)
            labels.append(active['shape'] if active else 'closed')
        viseme['frames'][who]=labels
    (HERE/'viseme-cues.json').write_text(json.dumps(viseme,indent=2),encoding='utf-8')
    (HERE/'English-dialogue.srt').write_text('\n\n'.join(f"{i+1}\n{srt_time(c['start'])} --> {srt_time(c['end'])}\n{c['text']}" for i,c in enumerate(d['cues']))+'\n',encoding='utf-8')
    d.update({'status':'v8_generated_timed_local_review','dialogue_master':str(voicepath.resolve()),'final_audio_mix':str(final.resolve()),'mouth_envelopes':str((HERE/'mouth-envelopes-120fps.json').resolve()),'viseme_cues':str((HERE/'viseme-cues.json').resolve()),'listening_review':'Agent has not performed perceptual listening; casting is based on available voice descriptions, native-pitch synthesis and timing/level verification. Owner review required.','commercial_use_rights':'Not represented as verified; private review only.','music':False,'post_time_stretch':False,'post_pitch_shift':False,'breath_note':'No added breath recordings or hiss. Any breath-like prosody comes only from the generated voice.'})
    (FILM/'DIALOGUE.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
    (HERE/'AUDIO-VERIFICATION.json').write_text(json.dumps({'duration':24,'sample_rate':SR,'channels':1,'frames':len(combined),'peak_dbfs':20*math.log10(max(abs(combined))),'full_scale_samples':int(np.sum(abs(combined)>=.999)),'no_dialogue_overlap':all(a['end']<=b['start'] for a,b in zip(d['cues'],d['cues'][1:])),'human_listening_review':False,'cues':qa},indent=2),encoding='utf-8')
    inherited=json.loads((REFERENCE_INPUT/'audio/SOUND-MANIFEST.json').read_text(encoding='utf-8'))
    inherited['version']='v8-acting-redraw'
    inherited['voice_disclosure']=d['voice_disclosure'];inherited['foley_inherited_without_timing_change']=True
    inherited['inherited_source_manifest']={'path':str((REFERENCE_INPUT/'audio/SOUND-MANIFEST.json').resolve()),'sha256':sha(REFERENCE_INPUT/'audio/SOUND-MANIFEST.json'),'foley_original':str(foley_src.resolve()),'foley_original_sha256':sha(foley_src)}
    inherited['output']={'path':str(final.resolve()),'sha256':sha(final),'peak_dbfs':20*math.log10(max(abs(combined))),'rms_dbfs':20*math.log10(np.sqrt(np.mean(combined**2))),'full_scale_samples':0}
    for source in inherited['sources']:
        for key in ['local_license','local_license_evidence']:
            if key in source:source[key]=str((REFERENCE_INPUT/'audio'/source[key]).resolve())
    (HERE/'SOUND-MANIFEST.json').write_text(json.dumps(inherited,indent=2),encoding='utf-8')
    provenance={'voice_provider':'Microsoft Edge online TTS','client':'edge-tts 7.3.1','source':'https://github.com/rany2/edge-tts','payment':0,'account':False,'generation_count':d.get('generation_count',9),'real_person_imitation':False,'human_actor_recordings':False,'new_assets_uploaded':False,'submitted_data':'Short fictional dialogue text only','voices':{c['character']:c['voice'] for c in d['cues']},'native_pitch':True,'post_time_stretch':False,'native_service_rate_adjustments':{c['id']:c['rate'] for c in d['cues']},'cues':[{'id':c['id'],'path':c['audio_file'],'sha256':sha(Path(c['audio_file']))} for c in d['cues']]}
    (HERE/'VOICE-PROVENANCE.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    print(json.dumps({'cues':qa,'final_peak_dbfs':20*math.log10(max(abs(combined))),'final_sha256':sha(final),'viseme_events':len(events)},indent=2))

if __name__=='__main__':main()
