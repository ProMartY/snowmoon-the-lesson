# Historical audio pipeline reference

These are sanitized copies of the harnesses used to make and time the v8 generated-voice reference. They are retained so the production method is inspectable. **They are not a claim that the generated speech may be redistributed**, and they are not part of the default picture render.

All three scripts exit before processing or importing a service client unless `--enable-reference-processing` is explicitly passed. Do not enable service calls until you have established the terms and rights that apply to your own use. No account, credential, paid plan, client dependency tree or model is bundled.

The historical voice client was edge-tts 7.3.1 with the voices/rates in `../DIALOGUE.json`. `generate_v8.py` contains the initial opening take; `retake_opening.py` is the actual shortened replacement used by the final v8 timing. `prepare_v8.py` trims and levels the selected takes, calculates amplitude activity and approximate word/spelling mouth shapes, and combines them with separately supplied foley. It uses NumPy and FFmpeg as external dependencies.

Paths were changed to local relative inputs. The reference preparation expects separately obtained `licensed-input/audio/The-Lesson-CC0-foley-24s.wav` and `licensed-input/audio/SOUND-MANIFEST.json` under this folder. Source clips and their recorded offsets/filter/level recipe are documented in `CC0-SOUND-RECIPE.json`; no source recordings are bundled here. The original private A/B audition-output block was omitted because it does not make the delivered mix. Runtime files are written only when explicitly enabled.

The included picture timing data is the exact final timing. Re-generating a remote service take may produce different duration or prosody; it is not guaranteed to reproduce the reference audio byte for byte. A final public soundtrack must use separately established recording/service rights. The approved public version instead uses English captions and the CC0 effects mix under `../audio/`, without spoken voices.
