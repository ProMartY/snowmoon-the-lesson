# SPDX-License-Identifier: GPL-3.0-only
# Historical v8 audio pipeline reference; output rights were not established.
# ProMartY with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
import os, sys
if "--enable-reference-processing" not in sys.argv:
    raise SystemExit("Reference-only harness. No service or processing invoked. Read audio-reference/README.md before opting in with --enable-reference-processing.")
"""Private v8 English casting: native neural voices, no pitch transposition.
Only the short fictional dialogue text is transmitted. No account or payment.
"""
from pathlib import Path
import asyncio, json, sys, time

HERE=Path(__file__).resolve().parent
FILM=HERE.parent
REFERENCE_INPUT=HERE/'licensed-input'
import edge_tts

CUES=[
    {'id':'01-teacher-praise','character':'teacher','start':.45,'target_end':3.7,'text':"Well, Zei... you've got it. That's right.",'spoken_text':"Well, Zay... you've got it. That's right.",'voice':'en-GB-RyanNeural','rate':'-3%','direction':'A small warm acknowledgement, unforced pauses.'},
    {'id':'02-fin-reassure','character':'fin','start':9.15,'target_end':11.6,'text':"Easy. I've got you.",'spoken_text':"Easy. I've got you.",'voice':'en-GB-ThomasNeural','rate':'-3%','direction':'Quiet reassurance while supporting a friend.'},
    {'id':'03-zei-arm','character':'zei','start':12.,'target_end':13.25,'text':'My arm...','spoken_text':'My arm...','voice':'en-US-BrianMultilingualNeural','rate':'-3%','direction':'Short, subdued. No simulated scream or added breath.'},
    {'id':'04-teacher-question','character':'teacher','start':13.55,'target_end':14.75,'text':'Does it hurt?','spoken_text':'Does it hurt?','voice':'en-GB-RyanNeural','rate':'+0%','direction':'A gentle question.'},
    {'id':'05-zei-answer','character':'zei','start':15.,'target_end':17.05,'text':"A bit. I'll be okay.",'spoken_text':"A bit. I'll be okay.",'voice':'en-US-BrianMultilingualNeural','rate':'+0%','direction':'A tentative reassurance rather than a confident announcement.'},
    {'id':'06-teacher-check','character':'teacher','start':17.2,'target_end':18.75,'text':'Get it checked today.','spoken_text':'Get it checked today.','voice':'en-GB-RyanNeural','rate':'+0%','direction':'Calm, direct, not a medical guarantee.'},
    {'id':'07-fin-offer','character':'fin','start':19.05,'target_end':20.6,'text':"I'll take you.",'spoken_text':"I'll take you.",'voice':'en-GB-ThomasNeural','rate':'-2%','direction':'A simple caring offer.'},
    {'id':'08-zei-wall','character':'zei','start':21.1,'target_end':23.75,'text':'I know less about that wall now.','spoken_text':'I know less about that wall now.','voice':'en-US-BrianMultilingualNeural','rate':'+0%','direction':'Dry and restrained, slight shared relief.'},
]

async def main():
    raw=HERE/'raw';raw.mkdir(exist_ok=True)
    journal=[]
    voices=await edge_tts.list_voices()
    names={v['ShortName'] for v in voices}
    chosen={c['voice'] for c in CUES}
    missing=chosen-names
    if missing: raise RuntimeError(f'Unavailable voice(s): {missing}')
    (HERE/'voice-catalog-selection.json').write_text(json.dumps([v for v in voices if v['ShortName'] in chosen],indent=2),encoding='utf-8')
    for c in CUES:
        c.update({'pitch':'+0Hz','volume':'-12%'})
        target=raw/(c['id']+'.mp3')
        if target.exists() and target.stat().st_size>1000:
            journal.append({'id':c['id'],'status':'already_exists_not_regenerated'})
            continue
        print('Generating '+c['id']+' / '+c['voice'],flush=True)
        boundaries=[]
        try:
            comm=edge_tts.Communicate(c['spoken_text'],c['voice'],rate=c['rate'],pitch='+0Hz',volume='-12%',boundary='WordBoundary')
            with target.open('wb') as out:
                async for part in comm.stream():
                    if part['type']=='audio':out.write(part['data'])
                    elif part['type'] in ('WordBoundary','SentenceBoundary'):boundaries.append(part)
            target.with_suffix('.words.json').write_text(json.dumps(boundaries,indent=2),encoding='utf-8')
            journal.append({'id':c['id'],'status':'generated','voice':c['voice'],'rate':c['rate'],'pitch':'+0Hz','volume':'-12%','bytes':target.stat().st_size,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
        except Exception as exc:
            journal.append({'id':c['id'],'status':'failed','error':repr(exc)})
            (HERE/'generation-journal.json').write_text(json.dumps(journal,indent=2),encoding='utf-8')
            raise
        (HERE/'generation-journal.json').write_text(json.dumps(journal,indent=2),encoding='utf-8')
    dialogue={'version':'v8-acting-redraw','language':'English','total_film_duration_seconds':24,'status':'neural_cues_generated_pending_timing','source':'https://vitalik.eth.limo/snowmoon/html/chapter-2.html','adaptation_note':'Compressed dialogue adaptation; Zei spoken as Zay, pronunciation unverified. The opening line is complete, not a literal mid-sentence interruption.','voice_disclosure':'Generated neural voices, not actor recordings or voice clones. Native pitch; no post time-stretch.','provider':'Microsoft Edge online TTS via edge-tts 7.3.1','provider_cost':0,'account_used':False,'cues':CUES,'generation_count':8,'human_listening_review_performed':False,'publication_authorized':False}
    (FILM/'DIALOGUE.json').write_text(json.dumps(dialogue,indent=2),encoding='utf-8')
    print('All eight v8 dialogue cues generated without a subscription.',flush=True)

asyncio.run(main())
