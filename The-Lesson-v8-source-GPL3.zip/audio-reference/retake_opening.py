# SPDX-License-Identifier: GPL-3.0-only
# Historical v8 audio pipeline reference; output rights were not established.
# ProMartY with OpenAI Codex assistance; Snowmoon: Vitalik Buterin.
import os, sys
if "--enable-reference-processing" not in sys.argv:
    raise SystemExit("Reference-only harness. No service or processing invoked. Read audio-reference/README.md before opting in with --enable-reference-processing.")
from pathlib import Path
import asyncio,json,sys,time
HERE=Path(__file__).resolve().parent
import edge_tts

async def main():
    cid='01-teacher-praise';p=HERE/'raw'/(cid+'.mp3')
    p.rename(p.with_name(cid+'-take01.mp3'))
    p.with_suffix('.words.json').rename(p.with_name(cid+'-take01.words.json'))
    words=[]
    c=edge_tts.Communicate("Well, Zay... you've got it right.",'en-GB-RyanNeural',rate='+0%',pitch='+0Hz',volume='-12%',boundary='WordBoundary')
    with p.open('wb') as out:
        async for q in c.stream():
            if q['type']=='audio':out.write(q['data'])
            elif q['type'] in ('WordBoundary','SentenceBoundary'):words.append(q)
    p.with_suffix('.words.json').write_text(json.dumps(words,indent=2),encoding='utf-8')
    d=json.loads((HERE.parent/'DIALOGUE.json').read_text());d['cues'][0].update({'text':"Well, Zei... you've got it right.",'spoken_text':"Well, Zay... you've got it right.",'rate':'+0%','take':2});d['generation_count']=9
    (HERE.parent/'DIALOGUE.json').write_text(json.dumps(d,indent=2),encoding='utf-8')
    j=json.loads((HERE/'generation-journal.json').read_text());j.append({'id':cid,'status':'replacement_generated','take':2,'reason':'Opening take01 exceeded target window. Shorter utterance, no post time stretch.','voice':'en-GB-RyanNeural','rate':'+0%','pitch':'+0Hz','volume':'-12%','utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())});(HERE/'generation-journal.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
    print('Opening shortened at native pitch and natural service rate.')

asyncio.run(main())
